import { Ionicons } from "@expo/vector-icons";
import { useState } from "react";
import { Pressable, ScrollView, StyleSheet, Switch, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { ScreenContainer } from "@/components/screen-container";

export default function SettingsScreen() {
  const insets = useSafeAreaInsets();
  const [notifications, setNotifications] = useState(true);
  const [language, setLanguage] = useState<"AR" | "EN">("AR");
  return (
    <ScreenContainer style={styles.screen}>
      <ScrollView contentContainerStyle={[styles.container, { paddingTop: Math.max(insets.top, 22) }]}>
        <View style={styles.header}><View><Text style={styles.eyebrow}>ZENOX / CONTROL</Text><Text style={styles.title}>الإعدادات</Text><Text style={styles.subtitle}>تحكم هادئ في تجربة التطبيق.</Text></View><View style={styles.settingsIcon}><Ionicons name="options" size={20} color="#A78BFA" /></View></View>
        <Text style={styles.section}>الحساب والتطبيق</Text>
        <View style={styles.panel}>
          <View style={styles.row}><View style={styles.rowIcon}><Ionicons name="language-outline" size={19} color="#67E8F9" /></View><View style={styles.rowCopy}><Text style={styles.rowTitle}>اللغة</Text><Text style={styles.rowSub}>العربية / English</Text></View><View style={styles.segment}><Pressable onPress={() => setLanguage("AR")} style={[styles.segmentButton, language === "AR" && styles.segmentActive]}><Text style={[styles.segmentText, language === "AR" && styles.segmentTextActive]}>عربي</Text></Pressable><Pressable onPress={() => setLanguage("EN")} style={[styles.segmentButton, language === "EN" && styles.segmentActive]}><Text style={[styles.segmentText, language === "EN" && styles.segmentTextActive]}>EN</Text></Pressable></View></View>
          <View style={styles.divider} />
          <View style={styles.row}><View style={styles.rowIcon}><Ionicons name="moon-outline" size={19} color="#C084FC" /></View><View style={styles.rowCopy}><Text style={styles.rowTitle}>السمة</Text><Text style={styles.rowSub}>Midnight Aurora</Text></View><View style={styles.themeSwatch}><View style={styles.swatchPurple} /><View style={styles.swatchTeal} /></View></View>
          <View style={styles.divider} />
          <View style={styles.row}><View style={styles.rowIcon}><Ionicons name="notifications-outline" size={19} color="#FBBF24" /></View><View style={styles.rowCopy}><Text style={styles.rowTitle}>إشعارات الحالة</Text><Text style={styles.rowSub}>تنبيهات الوكيل والتحديثات</Text></View><Switch value={notifications} onValueChange={setNotifications} trackColor={{ false: "#27304D", true: "#5B35B6" }} thumbColor={notifications ? "#C4B5FD" : "#94A3B8"} /></View>
        </View>
        <Text style={styles.section}>الأمان والخصوصية</Text>
        <View style={styles.panel}>
          <View style={styles.row}><View style={styles.rowIcon}><Ionicons name="shield-checkmark-outline" size={19} color="#2DD4BF" /></View><View style={styles.rowCopy}><Text style={styles.rowTitle}>سياسة الخصوصية</Text><Text style={styles.rowSub}>راجع ما يتم حفظه ومشاركته</Text></View><Ionicons name="chevron-back" size={18} color="#64748B" /></View>
          <View style={styles.divider} />
          <View style={styles.row}><View style={styles.rowIcon}><Ionicons name="cloud-outline" size={19} color="#60A5FA" /></View><View style={styles.rowCopy}><Text style={styles.rowTitle}>حالة الاتصال</Text><Text style={styles.rowSub}>كل وظائف ZENOX تعمل Online</Text></View><View style={styles.status}><View style={styles.dot} /><Text style={styles.statusText}>متصل</Text></View></View>
        </View>
        <Text style={styles.version}>ZENOX v0.1 · DON ALVARO · نسخة تجريبية</Text>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: "#0A0D1F" },
  container: { paddingHorizontal: 18, paddingBottom: 38, width: "100%", maxWidth: 900, alignSelf: "center" },
  header: { flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 28 },
  eyebrow: { color: "#67E8F9", fontSize: 10, fontWeight: "800", letterSpacing: 1.5, textAlign: "right", marginBottom: 8 },
  title: { color: "#F8FAFC", fontSize: 27, fontWeight: "900", textAlign: "right" },
  subtitle: { color: "#94A3B8", fontSize: 12, textAlign: "right", marginTop: 7 },
  settingsIcon: { width: 42, height: 42, borderRadius: 14, backgroundColor: "#211846", alignItems: "center", justifyContent: "center" },
  section: { color: "#64748B", fontSize: 11, fontWeight: "800", textAlign: "right", marginBottom: 9, letterSpacing: 0.6 },
  panel: { backgroundColor: "#11162B", borderWidth: 1, borderColor: "#232D4B", borderRadius: 18, paddingHorizontal: 14, marginBottom: 24 },
  row: { flexDirection: "row-reverse", alignItems: "center", minHeight: 70, gap: 11 },
  rowIcon: { width: 36, height: 36, borderRadius: 12, backgroundColor: "#1A2140", alignItems: "center", justifyContent: "center" },
  rowCopy: { flex: 1 },
  rowTitle: { color: "#F8FAFC", fontSize: 13, fontWeight: "800", textAlign: "right" },
  rowSub: { color: "#8190AD", fontSize: 11, textAlign: "right", marginTop: 4 },
  divider: { height: 1, backgroundColor: "#232D4B" },
  segment: { flexDirection: "row", backgroundColor: "#0A0D1F", borderRadius: 9, padding: 3 },
  segmentButton: { paddingHorizontal: 8, paddingVertical: 5, borderRadius: 7 },
  segmentActive: { backgroundColor: "#5B35B6" },
  segmentText: { color: "#8190AD", fontSize: 10, fontWeight: "700" },
  segmentTextActive: { color: "#FFFFFF" },
  themeSwatch: { flexDirection: "row", gap: 5 },
  swatchPurple: { width: 12, height: 12, borderRadius: 6, backgroundColor: "#8B5CF6" },
  swatchTeal: { width: 12, height: 12, borderRadius: 6, backgroundColor: "#2DD4BF" },
  status: { flexDirection: "row", alignItems: "center", gap: 5 },
  dot: { width: 7, height: 7, borderRadius: 4, backgroundColor: "#2DD4BF" },
  statusText: { color: "#99F6E4", fontSize: 11, fontWeight: "700" },
  version: { color: "#475569", textAlign: "center", fontSize: 10, marginTop: 20 },
});
