import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const deviceSessions = mysqlTable("device_sessions", {
  sessionId: varchar("sessionId", { length: 64 }).primaryKey(),
  ownerOpenId: varchar("ownerOpenId", { length: 64 }).notNull(),
  deviceId: varchar("deviceId", { length: 128 }).notNull(),
  deviceName: varchar("deviceName", { length: 160 }).notNull(),
  platform: varchar("platform", { length: 32 }).notNull(),
  capabilities: text("capabilities").notNull(),
  consentTokenHash: varchar("consentTokenHash", { length: 128 }).notNull().unique(),
  status: mysqlEnum("status", ["pending", "active", "revoked", "expired"]).default("pending").notNull(),
  expiresAt: timestamp("expiresAt").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  acceptedAt: timestamp("acceptedAt"),
  revokedAt: timestamp("revokedAt"),
});

export type DeviceSession = typeof deviceSessions.$inferSelect;
export type InsertDeviceSession = typeof deviceSessions.$inferInsert;

export const deviceAuditLogs = mysqlTable("device_audit_logs", {
  id: int("id").autoincrement().primaryKey(),
  sessionId: varchar("sessionId", { length: 64 }).notNull(),
  ownerOpenId: varchar("ownerOpenId", { length: 64 }).notNull(),
  deviceId: varchar("deviceId", { length: 128 }).notNull(),
  capability: varchar("capability", { length: 80 }).notNull(),
  action: varchar("action", { length: 255 }).notNull(),
  result: mysqlEnum("result", ["allowed", "denied"]).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
