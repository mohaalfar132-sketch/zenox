import { and, eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { randomUUID } from "node:crypto";
import { deviceAuditLogs, deviceSessions, InsertDeviceSession, InsertUser, users } from "../drizzle/schema";
import { createConsentToken, hashConsentToken, type DeviceCapability } from "./device-policy";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch {
      console.warn("[Database] Failed to connect");
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user");
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function createDeviceSession(input: {
  ownerOpenId: string;
  deviceId: string;
  deviceName: string;
  platform: string;
  capabilities: DeviceCapability[];
  expiresAt: Date;
}) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة لإنشاء جلسة الجهاز");

  const sessionId = `ds_${randomUUID()}`;
  const consentToken = createConsentToken();
  const values: InsertDeviceSession = {
    sessionId,
    ownerOpenId: input.ownerOpenId,
    deviceId: input.deviceId,
    deviceName: input.deviceName,
    platform: input.platform,
    capabilities: JSON.stringify(input.capabilities),
    consentTokenHash: hashConsentToken(consentToken),
    status: "pending",
    expiresAt: input.expiresAt,
  };
  await db.insert(deviceSessions).values(values);
  return { sessionId, consentToken, expiresAt: input.expiresAt };
}

export async function acceptDeviceSession(input: { consentToken: string; deviceId: string; deviceName: string; platform: string }) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة لقبول جلسة الجهاز");

  const [session] = await db.select().from(deviceSessions).where(eq(deviceSessions.consentTokenHash, hashConsentToken(input.consentToken))).limit(1);
  if (!session || session.status !== "pending" || session.expiresAt.getTime() <= Date.now()) {
    throw new Error("طلب الموافقة غير صالح أو منتهٍ");
  }
  if (session.deviceId !== input.deviceId) throw new Error("الجهاز لا يطابق طلب الموافقة");

  await db.update(deviceSessions).set({ status: "active", deviceName: input.deviceName, platform: input.platform, acceptedAt: new Date() }).where(eq(deviceSessions.sessionId, session.sessionId));
  return { sessionId: session.sessionId, sessionToken: input.consentToken, ownerOpenId: session.ownerOpenId, capabilities: session.capabilities, expiresAt: session.expiresAt };
}

export async function authorizeDeviceAction(input: { sessionId: string; sessionToken: string; capability: DeviceCapability; action: string }) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة للتحقق من جلسة الجهاز");

  const [session] = await db.select().from(deviceSessions).where(eq(deviceSessions.sessionId, input.sessionId)).limit(1);
  const valid = Boolean(session && session.status === "active" && session.expiresAt.getTime() > Date.now() && hashConsentToken(input.sessionToken) === session.consentTokenHash && JSON.parse(session.capabilities).includes(input.capability));
  if (!session) throw new Error("جلسة الجهاز غير موجودة");

  await db.insert(deviceAuditLogs).values({ sessionId: session.sessionId, ownerOpenId: session.ownerOpenId, deviceId: session.deviceId, capability: input.capability, action: input.action.slice(0, 255), result: valid ? "allowed" : "denied" });
  if (!valid) throw new Error("الصلاحية غير متاحة أو انتهت جلسة الجهاز");
  return { allowed: true as const, deviceId: session.deviceId };
}

export async function revokeDeviceSession(ownerOpenId: string, sessionId: string) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة لإلغاء جلسة الجهاز");
  await db.update(deviceSessions).set({ status: "revoked", revokedAt: new Date() }).where(and(eq(deviceSessions.sessionId, sessionId), eq(deviceSessions.ownerOpenId, ownerOpenId)));
  return { revoked: true as const };
}
