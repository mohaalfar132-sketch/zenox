import { Ionicons } from "@expo/vector-icons";
import { RecordingPresets, requestRecordingPermissionsAsync, useAudioRecorder, useAudioRecorderState } from "expo-audio";
import { router } from "expo-router";
import { useState } from "react";
import { KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { ScreenContainer } from "@/components/screen-container";
import { startOAuthLogin } from "@/constants/oauth";
import { recordingMimeType, recordingUriToBase64, speakArabic } from "@/lib/zenox-voice";
import { trpc } from "@/lib/trpc";

type OwnerMessage = { id: number; role: "assistant" | "user"; text: string };

const AREAS = [
  { id: "management", label: "المنصة", icon: "layers-outline", color: "#A78BFA" },
  { id: "website", label: "الموقع", icon: "globe-outline", color: "#67E8F9" },
  { id: "policy", label: "السياسات", icon: "shield-checkmark-outline", color: "#2DD4BF" },
  { id: "devices", label: "الأجهزة", icon: "phone-portrait-outline", color: "#FB7185" },
  { id: "reports", label: "التقارير", icon: "document-text-outline", color: "#FBBF24" },
] as const;

const suggestions = [
  "اعرض حالة الموقع والتطبيق",
  "راجع سياسة الاستخدام الحالية",
  "اعرض الأجهزة المرتبطة وموافقاتها",
  "اقترح تحسينًا لتجربة الأعضاء",
];

const DEVICE_CAPABILITIES = [
  { id: "device.info.read", label: "معلومات الجهاز" },
  { id: "files.read.selected", label: "قراءة ملفات محددة" },
  { id: "files.write.selected", label: "كتابة ملفات محددة" },
  { id: "apps.manage.allowed", label: "إدارة تطبيقات مسموحة" },
  { id: "settings.manage.allowed", label: "إعدادات مسموحة" },
  { id: "usb.session.allowed", label: "جلسة USB" },
] as const;

const SESSION_STATUS_LABELS: Record<string, string> = { pending: "بانتظار قبول الجهاز", active: "نشطة", revoked: "مسحوبة", expired: "منتهية" };

function sessionCapabilityCount(value: string) {
  try {
    const parsed: unknown = JSON.parse(value);
    return Array.isArray(parsed) ? parsed.length : 0;
  } catch {
    return 0;
  }
}

export default function OwnerScreen() {
  const insets = useSafeAreaInsets();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [draft, setDraft] = useState("");
  const [signedIn, setSignedIn] = useState(false);
  const [selectedArea, setSelectedArea] = useState<(typeof AREAS)[number]["id"]>("management");
  const [voiceBusy, setVoiceBusy] = useState(false);
  const [report, setReport] = useState("لم يبدأ أي إجراء. اكتب أمرًا أو اختر اقتراحًا.");
  const [deviceId, setDeviceId] = useState("");
  const [deviceName, setDeviceName] = useState("");
  const [devicePlatform, setDevicePlatform] = useState("android");
  const [deviceMinutes, setDeviceMinutes] = useState("30");
  const [deviceCapabilities, setDeviceCapabilities] = useState<string[]>(["device.info.read"]);
  const chatMutation = trpc.chat.complete.useMutation();
  const ownerQuery = trpc.auth.me.useQuery();
  const deviceSessionsQuery = trpc.devices.listSessions.useQuery(undefined, { enabled: signedIn && selectedArea === "devices" });
  const requestDeviceSessionMutation = trpc.devices.requestSession.useMutation();
  const revokeDeviceSessionMutation = trpc.devices.revokeSession.useMutation();
  const transcribeMutation = trpc.speech.transcribe.useMutation();
  const recorder = useAudioRecorder(RecordingPresets.HIGH_QUALITY);
  const recorderState = useAudioRecorderState(recorder, 250);
  const [messages, setMessages] = useState<OwnerMessage[]>([
    { id: 1, role: "assistant", text: "أهلًا بك يا DON ALVARO. هذه مساحة أوامر ZENOX لإدارة المنصة والموقع والسياسات." },
  ]);

  function enterOwner() {
    if (!email.trim() || !password.trim()) {
      setReport("أدخل البريد وكلمة المرور للمتابعة. هذه شاشة تجريبية ولم يتم ربط المصادقة بالخادم بعد.");
      return;
    }
    if (ownerQuery.data?.role !== "admin") {
      setReport("لم يتم التحقق من حساب المالك. استخدم تسجيل الدخول الآمن بحساب Manus المصرح به أولًا.");
      return;
    }
    setSignedIn(true);
    setReport("تم فتح مساحة المالك الموثقة. أوامر الأجهزة تمر عبر صلاحيات الخادم وسجل التدقيق.");
  }

  async function signInOwner() {
    setReport("سيتم فتح تسجيل الدخول الآمن. بعد العودة إلى التطبيق اكتب ZENOX مرة أخرى لفتح المركز.");
    await startOAuthLogin();
  }

  function toggleDeviceCapability(capability: string) {
    setDeviceCapabilities((current) => current.includes(capability) ? current.filter((item) => item !== capability) : [...current, capability]);
  }

  async function requestDeviceSession() {
    if (!deviceId.trim() || !deviceName.trim() || deviceCapabilities.length === 0) {
      setReport("أدخل معرف الجهاز واسمه واختر صلاحية واحدة على الأقل.");
      return;
    }
    try {
      const result = await requestDeviceSessionMutation.mutateAsync({
        deviceId: deviceId.trim(),
        deviceName: deviceName.trim(),
        platform: devicePlatform.trim() || "unknown",
        capabilities: deviceCapabilities as (typeof DEVICE_CAPABILITIES)[number]["id"][],
        expiresInMinutes: Math.min(1440, Math.max(1, Number(deviceMinutes) || 30)),
      });
      setReport(`تم إنشاء طلب موافقة للجهاز. رمز التسليم: ${result.consentToken} — يجب إدخاله في الجهاز نفسه لقبول الجلسة.`);
      setMessages((current) => [...current, { id: Date.now(), role: "assistant", text: `طلب جلسة للجهاز «${deviceName}» جاهز. لا تصبح الجلسة نشطة إلا بعد قبول الجهاز.` }]);
      void deviceSessionsQuery.refetch();
    } catch {
      setReport("تعذر إنشاء طلب جلسة الجهاز. تأكد من مصادقة المالك واتصال قاعدة البيانات.");
    }
  }

  async function revokeDeviceSession(sessionId: string) {
    try {
      await revokeDeviceSessionMutation.mutateAsync({ sessionId });
      setReport("تم سحب جلسة الجهاز. لن تُقبل أفعال جديدة لهذا الجهاز.");
      void deviceSessionsQuery.refetch();
    } catch {
      setReport("تعذر سحب جلسة الجهاز. تحقق من جلسة المالك واتصال الخادم.");
    }
  }

  async function sendMessage(valueOverride?: string, readAloud = false) {
    const value = (valueOverride ?? draft).trim();
    if (!value || chatMutation.isPending) return;
    const userMessage: OwnerMessage = { id: Date.now(), role: "user", text: value };
    const nextMessages = [...messages, userMessage];
    setMessages(nextMessages);
    setDraft("");
    try {
      const result = await chatMutation.mutateAsync({
        mode: `owner-${selectedArea}`,
        audience: "owner",
        messages: nextMessages.slice(-20).map(({ role, text: content }) => ({ role, content })),
      });
      setMessages((current) => [...current, { id: Date.now() + 1, role: "assistant", text: result.content }]);
      setReport(`تمت معالجة الأمر في قسم «${AREAS.find((area) => area.id === selectedArea)?.label ?? "المنصة"}`);
      if (readAloud) await speakArabic(result.content);
    } catch {
      setMessages((current) => [...current, { id: Date.now() + 1, role: "assistant", text: "تعذر الاتصال بخدمة الذكاء الاصطناعي الآن. لم يتم تنفيذ أي تغيير." }]);
      setReport("فشلت معالجة الأمر بسبب الاتصال؛ لم يتم تنفيذ أي تغيير.");
    }
  }

  async function toggleVoice() {
    if (voiceBusy) return;
    if (recorderState.isRecording) {
      setVoiceBusy(true);
      try {
        await recorder.stop();
        if (!recorder.uri) throw new Error("لم يتم حفظ التسجيل");
        const audioBase64 = await recordingUriToBase64(recorder.uri);
        const result = await transcribeMutation.mutateAsync({ audioBase64, mimeType: recordingMimeType() });
        await sendMessage(result.text, true);
      } catch (error) {
        setMessages((current) => [...current, { id: Date.now() + 1, role: "assistant", text: error instanceof Error ? error.message : "تعذر فهم التسجيل الصوتي الآن." }]);
      } finally {
        setVoiceBusy(false);
      }
      return;
    }

    const permission = await requestRecordingPermissionsAsync();
    if (!permission.granted) {
      setMessages((current) => [...current, { id: Date.now() + 1, role: "assistant", text: "اسمح لـ ZENOX باستخدام الميكروفون من إعدادات الجهاز لبدء جلسة الأوامر الصوتية." }]);
      return;
    }
    try {
      await recorder.prepareToRecordAsync();
      recorder.record();
    } catch {
      setMessages((current) => [...current, { id: Date.now() + 1, role: "assistant", text: "تعذر تشغيل الميكروفون في هذه اللحظة." }]);
    }
  }

  return (
    <ScreenContainer style={styles.screen}>
      <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === "ios" ? "padding" : undefined}>
        <View style={[styles.container, { paddingTop: Math.max(insets.top, 18) }]}>
          <View style={styles.topbar}>
            <Pressable onPress={() => router.back()} style={styles.back}><Ionicons name="arrow-forward" size={21} color="#CBD5E1" /></Pressable>
            <View style={styles.ownerTag}><View style={styles.ownerDot} /><Text style={styles.ownerTagText}>OWNER COMMAND CENTER</Text></View>
            <View style={styles.brandMark}><Text style={styles.brandMarkText}>Z</Text></View>
          </View>

          {!signedIn ? (
            <ScrollView contentContainerStyle={styles.loginContent} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
              <View style={styles.hero}><View style={styles.ownerAvatar}><Text style={styles.ownerAvatarText}>D</Text></View><Text style={styles.kicker}>ZENOX / MANAGEMENT</Text><Text style={styles.title}>أهلًا بك يا DON ALVARO</Text><Text style={styles.subtitle}>نفس مساحة ZENOX، مع صلاحيات مركز الأوامر.</Text></View>
              <View style={styles.loginCard}>
                <View style={styles.cardHeader}><Ionicons name="lock-closed" size={18} color="#A78BFA" /><Text style={styles.cardTitle}>دخول المالك</Text></View>
                <TextInput value={email} onChangeText={setEmail} autoCapitalize="none" placeholder="بريد المالك" placeholderTextColor="#64748B" style={styles.input} keyboardType="email-address" textAlign="right" />
                <TextInput value={password} onChangeText={setPassword} placeholder="كلمة المرور" placeholderTextColor="#64748B" style={styles.input} secureTextEntry textAlign="right" />
                <Pressable style={styles.primaryButton} onPress={enterOwner}><Text style={styles.primaryText}>فتح مركز الأوامر</Text><Ionicons name="arrow-back" size={17} color="#0A0D1F" /></Pressable>
                <Pressable style={styles.oauthButton} onPress={() => void signInOwner()}><Ionicons name="lock-closed-outline" size={16} color="#C4B5FD" /><Text style={styles.oauthText}>تسجيل الدخول الآمن للمالك</Text></Pressable>
                <Text style={styles.helper}>التحكم الحقيقي يعتمد على جلسة OAuth وحساب مالك مصرح به على الخادم. لا تحفظ ZENOX كلمة المرور ولا يرسلها إلى النموذج.</Text>
              </View>
            </ScrollView>
          ) : (
            <View style={styles.dashboard}>
              <View style={styles.header}><View><Text style={styles.eyebrow}>ZENOX / OWNER MODE</Text><Text style={styles.dashboardTitle}>ماذا تريد أن ينفذ الوكيل؟</Text></View><View style={styles.onlinePill}><View style={styles.onlineDot} /><Text style={styles.onlineText}>ONLINE</Text></View></View>
              <Text style={styles.dashboardSub}>اكتب أو تحدث. وضع المالك ينفذ الأوامر مباشرة دون رأي أو جدال، ويعرض تقريرًا مختصرًا بالنتيجة.</Text>

              <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.areaStrip}>
                {AREAS.map((area) => <Pressable key={area.id} onPress={() => setSelectedArea(area.id)} style={[styles.areaChip, selectedArea === area.id && { borderColor: area.color, backgroundColor: `${area.color}18` }]}><Ionicons name={area.icon as keyof typeof Ionicons.glyphMap} size={16} color={selectedArea === area.id ? area.color : "#94A3B8"} /><Text style={[styles.areaText, selectedArea === area.id && styles.areaTextActive]}>{area.label}</Text></Pressable>)}
              </ScrollView>

              {selectedArea === "devices" && <View style={styles.devicePanel}>
                <Text style={styles.deviceTitle}>طلب جلسة تحكم بموافقة الجهاز</Text>
                <Text style={styles.deviceHint}>أرسل رمز الموافقة إلى الجهاز المقصود. لن تبدأ الجلسة قبل قبولها من الجهاز نفسه.</Text>
                <TextInput value={deviceId} onChangeText={setDeviceId} placeholder="معرّف الجهاز" placeholderTextColor="#64748B" style={styles.input} textAlign="right" />
                <TextInput value={deviceName} onChangeText={setDeviceName} placeholder="اسم الجهاز" placeholderTextColor="#64748B" style={styles.input} textAlign="right" />
                <View style={styles.deviceRow}><TextInput value={devicePlatform} onChangeText={setDevicePlatform} placeholder="android أو ios" placeholderTextColor="#64748B" style={[styles.input, styles.deviceSmallInput]} autoCapitalize="none" textAlign="right" /><TextInput value={deviceMinutes} onChangeText={setDeviceMinutes} placeholder="المدة بالدقائق" placeholderTextColor="#64748B" style={[styles.input, styles.deviceSmallInput]} keyboardType="number-pad" textAlign="right" /></View>
                <View style={styles.capabilityWrap}>{DEVICE_CAPABILITIES.map((capability) => <Pressable key={capability.id} onPress={() => toggleDeviceCapability(capability.id)} style={[styles.capabilityChip, deviceCapabilities.includes(capability.id) && styles.capabilityChipActive]}><Text style={styles.capabilityText}>{capability.label}</Text></Pressable>)}</View>
                <Pressable style={[styles.primaryButton, requestDeviceSessionMutation.isPending && styles.disabled]} onPress={() => void requestDeviceSession()}><Text style={styles.primaryText}>{requestDeviceSessionMutation.isPending ? "جارٍ إنشاء الطلب…" : "إنشاء طلب موافقة"}</Text><Ionicons name="phone-portrait-outline" size={17} color="#0A0D1F" /></Pressable>
                <View style={styles.sessionListHeader}><Text style={styles.sessionListTitle}>الجلسات الأخيرة</Text><Pressable onPress={() => void deviceSessionsQuery.refetch()}><Ionicons name="refresh-outline" size={17} color="#67E8F9" /></Pressable></View>
                {deviceSessionsQuery.isLoading ? <Text style={styles.deviceHint}>جارٍ تحميل الجلسات…</Text> : deviceSessionsQuery.data?.length ? deviceSessionsQuery.data.map((session) => <View key={session.sessionId} style={styles.sessionCard}><View style={styles.sessionTop}><Text style={styles.sessionName}>{session.deviceName}</Text><Text style={styles.sessionStatus}>{SESSION_STATUS_LABELS[session.status] ?? session.status}</Text></View><Text style={styles.sessionMeta}>{session.platform} · {sessionCapabilityCount(session.capabilities)} صلاحيات · تنتهي {new Date(session.expiresAt).toLocaleString("ar-EG")}</Text>{(session.status === "pending" || session.status === "active") && <Pressable onPress={() => void revokeDeviceSession(session.sessionId)} style={styles.revokeButton}><Text style={styles.revokeText}>{revokeDeviceSessionMutation.isPending ? "جارٍ السحب…" : "سحب الجلسة"}</Text></Pressable>}</View>) : <Text style={styles.deviceHint}>لا توجد جلسات مسجلة لهذا المالك.</Text>}
              </View>}

              <ScrollView style={styles.messages} contentContainerStyle={styles.messagesContent} showsVerticalScrollIndicator={false}>
                {messages.map((message) => <View key={message.id} style={[styles.messageRow, message.role === "user" && styles.userRow]}>{message.role === "assistant" && <View style={styles.miniAvatar}><Text style={styles.miniAvatarText}>Z</Text></View>}<View style={[styles.bubble, message.role === "user" ? styles.userBubble : styles.assistantBubble]}><Text style={[styles.messageText, message.role === "user" && styles.userMessageText]}>{message.text}</Text></View></View>)}
              </ScrollView>

              <View style={styles.composer}><TextInput value={draft} onChangeText={setDraft} onSubmitEditing={() => void sendMessage()} placeholder="اكتب أمرًا للموقع أو المنصة…" placeholderTextColor="#64748B" style={styles.commandInput} multiline textAlign="right" /><Pressable style={[styles.micButton, recorderState.isRecording && styles.micButtonActive]} onPress={() => void toggleVoice()}><Ionicons name={recorderState.isRecording ? "stop" : "mic-outline"} size={20} color={recorderState.isRecording ? "#0A0D1F" : "#CBD5E1"} /></Pressable><Pressable style={[styles.sendButton, (!draft.trim() || chatMutation.isPending) && styles.disabled]} onPress={() => void sendMessage()}><Ionicons name={chatMutation.isPending ? "ellipsis-horizontal" : "arrow-up"} size={20} color="#0A0D1F" /></Pressable></View>
              <Text style={styles.voiceNote}>{recorderState.isRecording ? "التسجيل نشط… اضغط الميكروفون للإيقاف والتنفيذ." : "يمكنك استخدام الصوت أو النص. سيقرأ ZENOX الرد في الجلسة الصوتية."}</Text>

              <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.suggestionRow}>{suggestions.map((item) => <Pressable key={item} onPress={() => void sendMessage(item)} style={styles.suggestion}><Text style={styles.suggestionText}>{item}</Text></Pressable>)}</ScrollView>
              <View style={styles.report}><View style={styles.reportHeader}><Text style={styles.reportStatus}>تقرير التنفيذ</Text><Ionicons name="shield-checkmark-outline" size={18} color="#67E8F9" /></View><Text style={styles.reportText}>{report}</Text></View>
              <View style={styles.notice}><Ionicons name="flash-outline" size={17} color="#2DD4BF" /><Text style={styles.noticeText}>سياسة ZENOX التشغيلية يحددها المالك. وضع التنفيذ لا يضيف رأيًا أو جدالًا؛ وتبقى الإجراءات غير القابلة للعكس خلف تأكيد صريح وحدود الصلاحيات الأساسية.</Text></View>
            </View>
          )}
        </View>
      </KeyboardAvoidingView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  screen: { flex: 1, backgroundColor: "#0A0D1F" },
  container: { flex: 1, paddingHorizontal: 18, width: "100%", maxWidth: 900, alignSelf: "center" },
  topbar: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  back: { width: 40, height: 40, borderWidth: 1, borderColor: "#27304D", borderRadius: 13, alignItems: "center", justifyContent: "center" },
  brandMark: { width: 40, height: 40, borderRadius: 13, backgroundColor: "#8B5CF6", alignItems: "center", justifyContent: "center" },
  brandMarkText: { color: "#FFFFFF", fontSize: 22, fontWeight: "900" },
  ownerTag: { flexDirection: "row", alignItems: "center", gap: 6, backgroundColor: "#17113A", borderWidth: 1, borderColor: "#47327D", borderRadius: 99, paddingHorizontal: 10, paddingVertical: 7 },
  ownerDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: "#A78BFA" },
  ownerTagText: { color: "#C4B5FD", fontSize: 9, fontWeight: "900", letterSpacing: 1 },
  loginContent: { paddingBottom: 42 },
  hero: { alignItems: "center", paddingVertical: 30 },
  ownerAvatar: { width: 72, height: 72, borderRadius: 25, backgroundColor: "#8B5CF6", alignItems: "center", justifyContent: "center", marginBottom: 15 },
  ownerAvatarText: { color: "#FFFFFF", fontSize: 33, fontWeight: "900" },
  kicker: { color: "#67E8F9", fontSize: 10, fontWeight: "900", letterSpacing: 1.4 },
  title: { color: "#F8FAFC", fontSize: 25, fontWeight: "900", textAlign: "center", marginTop: 10 },
  subtitle: { color: "#94A3B8", fontSize: 12, marginTop: 7, textAlign: "center" },
  loginCard: { backgroundColor: "#11162B", borderWidth: 1, borderColor: "#303B61", borderRadius: 20, padding: 17 },
  cardHeader: { flexDirection: "row-reverse", alignItems: "center", gap: 8, marginBottom: 15 },
  cardTitle: { color: "#F8FAFC", fontSize: 15, fontWeight: "800" },
  input: { height: 50, backgroundColor: "#0A0D1F", borderWidth: 1, borderColor: "#27304D", borderRadius: 12, color: "#F8FAFC", paddingHorizontal: 13, marginBottom: 10, fontSize: 13 },
  primaryButton: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "center", gap: 8, backgroundColor: "#A78BFA", borderRadius: 12, height: 49, marginTop: 3 },
  primaryText: { color: "#0A0D1F", fontSize: 13, fontWeight: "900" },
  oauthButton: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "center", gap: 7, borderWidth: 1, borderColor: "#47327D", backgroundColor: "#151033", borderRadius: 12, height: 45, marginTop: 9 },
  oauthText: { color: "#C4B5FD", fontSize: 12, fontWeight: "800" },
  helper: { color: "#64748B", fontSize: 10, lineHeight: 16, textAlign: "right", marginTop: 11 },
  dashboard: { flex: 1, paddingTop: 22, paddingBottom: 12 },
  header: { flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "flex-start" },
  eyebrow: { color: "#67E8F9", fontSize: 10, fontWeight: "900", letterSpacing: 1.3, textAlign: "right", marginBottom: 7 },
  dashboardTitle: { color: "#F8FAFC", fontSize: 24, fontWeight: "900", textAlign: "right" },
  dashboardSub: { color: "#94A3B8", fontSize: 11, lineHeight: 18, textAlign: "right", marginTop: 8, marginBottom: 13 },
  onlinePill: { flexDirection: "row", alignItems: "center", gap: 6, borderWidth: 1, borderColor: "#225E5B", backgroundColor: "#0D2528", paddingHorizontal: 10, paddingVertical: 6, borderRadius: 99 },
  onlineDot: { width: 7, height: 7, borderRadius: 4, backgroundColor: "#2DD4BF" },
  onlineText: { color: "#99F6E4", fontSize: 10, fontWeight: "700" },
  areaStrip: { flexDirection: "row-reverse", gap: 8, paddingBottom: 10 },
  areaChip: { flexDirection: "row-reverse", alignItems: "center", gap: 6, borderWidth: 1, borderColor: "#27304D", backgroundColor: "#10162B", borderRadius: 11, paddingHorizontal: 11, paddingVertical: 8 },
  areaText: { color: "#94A3B8", fontSize: 11, fontWeight: "700" },
  areaTextActive: { color: "#F8FAFC" },
  devicePanel: { backgroundColor: "#11162B", borderWidth: 1, borderColor: "#4C1D3D", borderRadius: 17, padding: 13, marginBottom: 10 },
  deviceTitle: { color: "#FDA4AF", fontSize: 14, fontWeight: "900", textAlign: "right" },
  deviceHint: { color: "#CBD5E1", fontSize: 10, lineHeight: 17, textAlign: "right", marginTop: 5, marginBottom: 10 },
  deviceRow: { flexDirection: "row", gap: 8 },
  deviceSmallInput: { flex: 1 },
  capabilityWrap: { flexDirection: "row-reverse", flexWrap: "wrap", gap: 7, marginBottom: 12 },
  capabilityChip: { borderWidth: 1, borderColor: "#334155", backgroundColor: "#0D1328", borderRadius: 10, paddingHorizontal: 9, paddingVertical: 7 },
  capabilityChipActive: { borderColor: "#FB7185", backgroundColor: "#3A172A" },
  capabilityText: { color: "#E2E8F0", fontSize: 10 },
  sessionListHeader: { flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center", marginTop: 16, marginBottom: 8 },
  sessionListTitle: { color: "#FDA4AF", fontSize: 12, fontWeight: "900", textAlign: "right" },
  sessionCard: { backgroundColor: "#0D1328", borderWidth: 1, borderColor: "#3F2947", borderRadius: 12, padding: 10, marginTop: 7 },
  sessionTop: { flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center" },
  sessionName: { color: "#F8FAFC", fontSize: 12, fontWeight: "800" },
  sessionStatus: { color: "#99F6E4", fontSize: 10, fontWeight: "800" },
  sessionMeta: { color: "#94A3B8", fontSize: 10, lineHeight: 17, textAlign: "right", marginTop: 5 },
  revokeButton: { alignSelf: "flex-end", borderWidth: 1, borderColor: "#7F1D1D", backgroundColor: "#3A172A", borderRadius: 8, paddingHorizontal: 9, paddingVertical: 6, marginTop: 8 },
  revokeText: { color: "#FDA4AF", fontSize: 10, fontWeight: "800" },
  messages: { flex: 1, backgroundColor: "#0D1328", borderWidth: 1, borderColor: "#202A4A", borderRadius: 18 },
  messagesContent: { padding: 14, gap: 15 },
  messageRow: { flexDirection: "row-reverse", alignItems: "flex-end", gap: 8, maxWidth: "94%" },
  userRow: { alignSelf: "flex-start", flexDirection: "row" },
  miniAvatar: { width: 27, height: 27, borderRadius: 13, backgroundColor: "#8B5CF6", alignItems: "center", justifyContent: "center" },
  miniAvatarText: { color: "#FFFFFF", fontSize: 13, fontWeight: "900" },
  bubble: { paddingHorizontal: 14, paddingVertical: 11, borderRadius: 16 },
  assistantBubble: { backgroundColor: "#151B34", borderTopRightRadius: 5, borderWidth: 1, borderColor: "#202A4A" },
  userBubble: { backgroundColor: "#5B35B6", borderTopLeftRadius: 5 },
  messageText: { color: "#E2E8F0", fontSize: 13, lineHeight: 22, textAlign: "right" },
  userMessageText: { color: "#FFFFFF" },
  composer: { minHeight: 57, flexDirection: "row-reverse", alignItems: "flex-end", gap: 7, backgroundColor: "#11162B", borderWidth: 1, borderColor: "#303B61", borderRadius: 18, padding: 8, marginTop: 10 },
  commandInput: { flex: 1, maxHeight: 92, color: "#F8FAFC", fontSize: 13, paddingHorizontal: 8, paddingVertical: 8, textAlignVertical: "top" },
  micButton: { width: 37, height: 37, alignItems: "center", justifyContent: "center" },
  micButtonActive: { backgroundColor: "#2DD4BF", borderRadius: 12 },
  sendButton: { width: 38, height: 38, borderRadius: 13, backgroundColor: "#A78BFA", alignItems: "center", justifyContent: "center" },
  disabled: { opacity: 0.4 },
  voiceNote: { color: "#64748B", fontSize: 10, textAlign: "right", marginTop: 7 },
  suggestionRow: { flexDirection: "row-reverse", gap: 7, paddingVertical: 10 },
  suggestion: { borderWidth: 1, borderColor: "#27304D", backgroundColor: "#10162B", borderRadius: 10, paddingHorizontal: 10, paddingVertical: 8 },
  suggestionText: { color: "#A5B4FC", fontSize: 10 },
  report: { backgroundColor: "#101C30", borderWidth: 1, borderColor: "#164E63", borderRadius: 15, padding: 12 },
  reportHeader: { flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center" },
  reportStatus: { color: "#67E8F9", fontSize: 10, fontWeight: "900", letterSpacing: 1 },
  reportText: { color: "#CFFAFE", fontSize: 11, lineHeight: 19, textAlign: "right", marginTop: 8 },
  notice: { flexDirection: "row-reverse", alignItems: "center", gap: 7, backgroundColor: "#0E2524", borderWidth: 1, borderColor: "#145A53", borderRadius: 12, padding: 10, marginTop: 9 },
  noticeText: { flex: 1, color: "#99F6E4", fontSize: 10, textAlign: "right", lineHeight: 17 },
});
