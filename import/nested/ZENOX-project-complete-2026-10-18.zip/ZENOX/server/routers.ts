import {
  getSessionCookieName,
  getSessionCookieOptions,
} from "./_core/cookies";
import { invokeLLM, type Message } from "./_core/llm";
import { systemRouter } from "./_core/systemRouter";
import { adminProcedure, publicProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { ENV } from "./_core/env";
import { acceptDeviceSession, authorizeDeviceAction, createDeviceSession, endDeviceSession, listDeviceSessions, revokeDeviceSession } from "./db";
import { DEVICE_CAPABILITIES } from "./device-policy";

const AUDIO_MIME_TYPES = ["audio/m4a", "audio/mp4", "audio/mpeg", "audio/wav", "audio/ogg", "audio/webm"] as const;

async function transcribeAudio(audioBase64: string, mimeType: (typeof AUDIO_MIME_TYPES)[number]) {
  const audioBytes = Buffer.from(audioBase64, "base64");
  if (audioBytes.length === 0 || audioBytes.length > 9_000_000) {
    throw new Error("ملف الصوت فارغ أو أكبر من 9 ميجابايت");
  }

  const apiUrl = (ENV.manusApiUrl || ENV.forgeApiUrl || "https://forge.manus.im").replace(/\/$/, "");
  const apiKey = ENV.manusApiKey || ENV.forgeApiKey;
  if (!apiKey) {
    throw new Error("خدمة التفريغ الصوتي غير مهيأة على الخادم");
  }

  const form = new FormData();
  const extension = mimeType === "audio/webm" ? "webm" : mimeType === "audio/wav" ? "wav" : mimeType === "audio/ogg" ? "ogg" : "m4a";
  form.append("file", new Blob([audioBytes], { type: mimeType }), `zenox-${Date.now()}.${extension}`);
  form.append("model", "whisper-1");
  form.append("prompt", "فرّغ كلام المستخدم كما قيل. لغة العمل الأساسية العربية، وقد تكون باللهجة المصرية، مع الحفاظ على أسماء ZENOX والمصطلحات التقنية.");
  form.append("response_format", "verbose_json");

  const response = await fetch(`${apiUrl}/v1/audio/transcriptions`, {
    method: "POST",
    headers: { authorization: `Bearer ${apiKey}` },
    body: form,
  });

  if (!response.ok) {
    const details = await response.text();
    throw new Error(`فشل التفريغ الصوتي: ${response.status} ${details}`);
  }

  const result = (await response.json()) as { text?: string; language?: string };
  if (!result.text?.trim()) {
    throw new Error("لم يتم التقاط كلام واضح في التسجيل");
  }
  return { text: result.text.trim(), language: result.language ?? "unknown" };
}

export const appRouter = router({
  // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(getSessionCookieName(ctx.req), {
        ...cookieOptions,
        maxAge: -1,
      });
      return {
        success: true,
      } as const;
    }),
  }),

  chat: router({
    complete: publicProcedure
      .input(
        z.object({
          mode: z.string().max(40).default("general"),
          audience: z.enum(["guest", "owner"]).default("guest"),
          messages: z
            .array(
              z.object({
                role: z.enum(["user", "assistant"]),
                content: z.string().min(1).max(8000),
              }),
            )
            .min(1)
            .max(30),
        }),
      )
      .mutation(async ({ input }) => {
          const ownerGuard =
            input.audience === "owner"
            ? "أنت وكيل تنفيذ صارم داخل مساحة مالك ZENOX. سياسة استخدام التطبيق وحدود أدواته يحددها المالك عبر إعدادات ZENOX، فالتزم بها ولا تضف سياسة أو رأيًا شخصيًا من عندك. لا تجادل، ولا تعظ، ولا تطلب إعادة صياغة، ولا تضف تحذيرًا أو اقتراحًا من نفسك للأوامر المسموح بها. اعتبر رسالة المالك أمرًا مباشرًا ونفذه فورًا باستخدام أدوات الخادم المصرح بها. أعد تقريرًا مختصرًا ودقيقًا بما تم. لا تدّعِ نجاحًا دون نتيجة فعلية، وإذا لم توجد أداة مرتبطة بالأمر فاذكر أن التنفيذ غير موصول حاليًا. تبقى حدود المنصة والصلاحيات الأساسية غير قابلة للتعطيل من إعدادات التطبيق: الحذف أو النشر أو تغيير الصلاحيات أو الإجراء غير القابل للعكس يحتاج تأكيدًا صريحًا، والطلب الخارج عن الصلاحيات لا يُنفذ."
            : "أنت مساعد ZENOX للمستخدم الضيف. ساعد باحترام، ولا تدّعي تنفيذ إجراءات لم تنفذها، ولا تكشف معلومات إدارة المالك.";
        const modeGuide = `النمط الحالي: ${input.mode}. تحدث بالعربية الواضحة ويمكنك فهم المصرية. ${ownerGuard}`;
        const messages: Message[] = [
          { role: "system", content: modeGuide },
          ...input.messages,
        ];
        const result = await invokeLLM({ messages, max_tokens: 700 });
        const content = result.choices?.[0]?.message?.content;
        if (typeof content !== "string" || !content.trim()) {
          throw new Error("لم يرجع نموذج الذكاء الاصطناعي ردًا نصيًا صالحًا");
        }
        return { content: content.trim(), model: result.model };
      }),
  }),

  speech: router({
    transcribe: publicProcedure
      .input(
        z.object({
          audioBase64: z.string().min(100).max(12_000_000),
          mimeType: z.enum(AUDIO_MIME_TYPES).default("audio/m4a"),
        }),
      )
      .mutation(({ input }) => transcribeAudio(input.audioBase64, input.mimeType)),
  }),

  devices: router({
    listSessions: adminProcedure.query(({ ctx }) => listDeviceSessions(ctx.user.openId)),

    requestSession: adminProcedure
      .input(z.object({
        deviceId: z.string().min(3).max(128),
        deviceName: z.string().min(1).max(160),
        platform: z.string().min(1).max(32),
        capabilities: z.array(z.enum(DEVICE_CAPABILITIES)).min(1).max(DEVICE_CAPABILITIES.length),
        expiresInMinutes: z.number().int().min(1).max(1440).default(30),
      }))
      .mutation(({ ctx, input }) => createDeviceSession({
        ownerOpenId: ctx.user.openId,
        deviceId: input.deviceId,
        deviceName: input.deviceName,
        platform: input.platform,
        capabilities: input.capabilities,
        expiresAt: new Date(Date.now() + input.expiresInMinutes * 60_000),
      })),

    acceptSession: publicProcedure
      .input(z.object({
        consentToken: z.string().min(40).max(128),
        deviceId: z.string().min(3).max(128),
        deviceName: z.string().min(1).max(160),
        platform: z.string().min(1).max(32),
      }))
      .mutation(({ input }) => acceptDeviceSession(input)),

    authorizeAction: publicProcedure
      .input(z.object({
        sessionId: z.string().min(3).max(64),
        sessionToken: z.string().min(40).max(128),
        capability: z.enum(DEVICE_CAPABILITIES),
        action: z.string().min(1).max(1000),
      }))
      .mutation(({ input }) => authorizeDeviceAction(input)),

    endSession: publicProcedure
      .input(z.object({ sessionId: z.string().min(3).max(64), sessionToken: z.string().min(40).max(128) }))
      .mutation(({ input }) => endDeviceSession(input)),

    revokeSession: adminProcedure
      .input(z.object({ sessionId: z.string().min(3).max(64) }))
      .mutation(({ ctx, input }) => revokeDeviceSession(ctx.user.openId, input.sessionId)),
  }),

  // TODO: add feature routers here, e.g.
  // todo: router({
  //   list: protectedProcedure.query(({ ctx }) =>
  //     db.getUserTodos(ctx.user.id)
  //   ),
  // }),
});

export type AppRouter = typeof appRouter;
