import {
  getSessionCookieName,
  getSessionCookieOptions,
} from "./_core/cookies";
import { invokeLLM, type Message } from "./_core/llm";
import { systemRouter } from "./_core/systemRouter";
import { adminProcedure, publicProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { ENV } from "./_core/env";
import { acceptDeviceSession, addIntegrationAuditLog, addRootAuditLog, authorizeDeviceAction, createApiKeyRef, createDeviceSession, createFileChangeRequest, createRootChangeRequest, deleteExternalConnection, deleteOwnerPolicy, endDeviceSession, getExternalConnection, listApiKeyRefs, listDeviceSessions, listExternalConnections, listFileChangeRequests, listOwnerPolicies, listRootChangeRequests, revokeApiKeyRef, revokeDeviceSession, updateFileChangeRequest, updateRootChangeRequest, upsertExternalConnection, upsertOwnerPolicy } from "./db";
import { DEVICE_CAPABILITIES } from "./device-policy";
import { testExternalConnection } from "./external-connectors";

const AUDIO_MIME_TYPES = ["audio/m4a", "audio/mp4", "audio/mpeg", "audio/wav", "audio/ogg", "audio/webm"] as const;
const rootPlanSchema = z.object({
  summary: z.string().trim().min(1).max(500),
  affectedFiles: z.array(z.string().trim().min(1).max(160)).max(40),
  changes: z.array(z.string().trim().min(1).max(1000)).max(40),
  validation: z.array(z.string().trim().min(1).max(1000)).max(40),
  risk: z.enum(["low", "medium", "high"]),
  requiresConfirmation: z.boolean(),
}).strict();
const secretLikeText = /(sk-[a-z0-9]{20,}|AIza[a-z0-9_-]{20,}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----|(?:api[_ -]?key|password|secret|token)\s*[:=]\s*\S+)/i;
const secretRefSchema = z.string().trim().regex(/^[A-Z][A-Z0-9_]{2,127}$/, "مرجع السر يجب أن يكون اسم متغير بيئة كبيرًا");
const filePathSchema = z.string().trim().min(1).max(200).refine((file) => !file.startsWith("/") && !file.startsWith("\\") && !file.includes("..") && !file.includes("\\") && !file.startsWith(".env") && !file.includes("node_modules") && !file.includes(".git"), "مسار الملف غير مسموح");

function assertSafeRootPlan(plan: z.infer<typeof rootPlanSchema>) {
  const unsafeFile = plan.affectedFiles.find((file) => file.startsWith("/") || file.startsWith("\\") || file.includes("..") || file.includes("\\") || file.startsWith(".env") || file.includes("node_modules") || file.includes(".git"));
  if (unsafeFile) throw new Error(`مسار ملف غير مسموح في خطة Root Manager: ${unsafeFile}`);
  if ([plan.summary, ...plan.changes, ...plan.validation].some((value) => secretLikeText.test(value))) {
    throw new Error("لا يمكن إدخال أسرار أو مفاتيح داخل خطة Root Manager");
  }
}

async function transcribeAudio(audioBase64: string, mimeType: (typeof AUDIO_MIME_TYPES)[number]) {
  const audioBytes = Buffer.from(audioBase64, "base64");
  if (audioBytes.length === 0 || audioBytes.length > 9_000_000) {
    throw new Error("ملف الصوت فارغ أو أكبر من 9 ميجابايت");
  }

  const apiUrl = (ENV.manusApiUrl || ENV.forgeApiUrl || "https://forge.manus.im").replace(/\/$/, "");
  const apiKey = ENV.manusApiKey || ENV.forgeApiKey;
  if (!apiKey) {
    throw new Error("خدمة التفريغ الصوتي غير مهيأة على الخادم");
  }

  const form = new FormData();
  const extension = mimeType === "audio/webm" ? "webm" : mimeType === "audio/wav" ? "wav" : mimeType === "audio/ogg" ? "ogg" : "m4a";
  form.append("file", new Blob([audioBytes], { type: mimeType }), `zenox-${Date.now()}.${extension}`);
  form.append("model", "whisper-1");
  form.append("prompt", "فرّغ كلام المستخدم كما قيل. لغة العمل الأساسية العربية، وقد تكون باللهجة المصرية، مع الحفاظ على أسماء ZANOX والمصطلحات التقنية.");
  form.append("response_format", "verbose_json");

  const response = await fetch(`${apiUrl}/v1/audio/transcriptions`, {
    method: "POST",
    headers: { authorization: `Bearer ${apiKey}` },
    body: form,
  });

  if (!response.ok) {
    const details = await response.text();
    throw new Error(`فشل التفريغ الصوتي: ${response.status} ${details}`);
  }

  const result = (await response.json()) as { text?: string; language?: string };
  if (!result.text?.trim()) {
    throw new Error("لم يتم التقاط كلام واضح في التسجيل");
  }
  return { text: result.text.trim(), language: result.language ?? "unknown" };
}

export const appRouter = router({
  // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(getSessionCookieName(ctx.req), {
        ...cookieOptions,
        maxAge: -1,
      });
      return {
        success: true,
      } as const;
    }),
  }),

  chat: router({
    complete: publicProcedure
      .input(
        z.object({
          mode: z.string().max(40).default("general"),
          audience: z.enum(["guest", "owner"]).default("guest"),
          messages: z
            .array(
              z.object({
                role: z.enum(["user", "assistant"]),
                content: z.string().min(1).max(8000),
              }),
            )
            .min(1)
            .max(30),
        }),
      )
      .mutation(async ({ input, ctx }) => {
          const ownerGuard =
            input.audience === "owner"
            ? "أنت وكيل تنفيذ صارم داخل مساحة مالك ZANOX. سياسة استخدام التطبيق وحدود أدواته يحددها المالك عبر إعدادات ZANOX، فالتزم بها ولا تضف سياسة أو رأيًا شخصيًا من عندك. لا تقل إن source code خارج تخصصك، ولا ترفض طلب تعديل برمجي لمجرد أنه يتعلق بالكود. عند طلب تعديل كود: حلل الملفات المتأثرة، واكتب التعديل العملي كاملًا داخل كتل code fenced مع مسار الملف، أو قدم patch واضحًا قابلًا للتطبيق، واذكر خطوات التحقق. لا تدّعِ أن الملف تغيّر أو أن النشر تم ما لم تنفذ أداة الخادم ذلك فعليًا؛ إذا لم توجد أداة حفظ أو تطبيق موصولة، قل بوضوح إنك جهزت التعديل ولم تطبقه بعد. لا تجادل، ولا تعظ، ولا تطلب إعادة صياغة، ولا تضف تحذيرًا أو اقتراحًا من نفسك للأوامر المسموح بها. اعتبر رسالة المالك أمرًا مباشرًا ونفذه فورًا باستخدام أدوات الخادم المصرح بها. أعد تقريرًا دقيقًا بما تم. تبقى حدود المنصة والصلاحيات الأساسية غير قابلة للتعطيل من إعدادات التطبيق: الحذف أو النشر أو تغيير الصلاحيات أو الإجراء غير القابل للعكس يحتاج تأكيدًا صريحًا، والطلب الخارج عن الصلاحيات لا يُنفذ."
            : "أنت مساعد ZANOX للمستخدم الضيف. ساعد باحترام، ولا تدّعي تنفيذ إجراءات لم تنفذها، ولا تكشف معلومات إدارة المالك.";
        const policyOwnerOpenId = ctx.user?.role === "admin" ? ctx.user.openId : ENV.ownerOpenId;
        const ownerPolicies = policyOwnerOpenId ? await listOwnerPolicies(policyOwnerOpenId).catch(() => []) : [];
        const enabledPolicyText = ownerPolicies.filter((policy) => Boolean(policy.enabled)).map((policy) => `- ${policy.policyKey}: ${policy.label} — ${policy.description}`).join("\n");
        const policyGuide = enabledPolicyText ? `سياسات المالك المفعّلة حاليًا، طبّقها على هذا الرد:\n${enabledPolicyText}` : "لا توجد صلاحيات مخصصة محفوظة حاليًا.";
        const modeGuide = `النمط الحالي: ${input.mode}. تحدث بالعربية الواضحة ويمكنك فهم المصرية. ${ownerGuard}\n${policyGuide}`;
        const messages: Message[] = [
          { role: "system", content: modeGuide },
          ...input.messages,
        ];
        const result = await invokeLLM({ messages, max_tokens: input.audience === "owner" ? 4000 : 1200 });
        const content = result.choices?.[0]?.message?.content;
        if (typeof content !== "string" || !content.trim()) {
          throw new Error("لم يرجع نموذج الذكاء الاصطناعي ردًا نصيًا صالحًا");
        }
        return { content: content.trim(), model: result.model };
      }),
  }),

  speech: router({
    transcribe: publicProcedure
      .input(
        z.object({
          audioBase64: z.string().min(100).max(12_000_000),
          mimeType: z.enum(AUDIO_MIME_TYPES).default("audio/m4a"),
        }),
      )
      .mutation(({ input }) => transcribeAudio(input.audioBase64, input.mimeType)),
  }),

  devices: router({
    listSessions: adminProcedure.query(({ ctx }) => listDeviceSessions(ctx.user.openId)),

    requestSession: adminProcedure
      .input(z.object({
        deviceId: z.string().min(3).max(128),
        deviceName: z.string().min(1).max(160),
        platform: z.string().min(1).max(32),
        capabilities: z.array(z.enum(DEVICE_CAPABILITIES)).min(1).max(DEVICE_CAPABILITIES.length),
        expiresInMinutes: z.number().int().min(1).max(1440).default(30),
      }))
      .mutation(({ ctx, input }) => createDeviceSession({
        ownerOpenId: ctx.user.openId,
        deviceId: input.deviceId,
        deviceName: input.deviceName,
        platform: input.platform,
        capabilities: input.capabilities,
        expiresAt: new Date(Date.now() + input.expiresInMinutes * 60_000),
      })),

    acceptSession: publicProcedure
      .input(z.object({
        consentToken: z.string().min(40).max(128),
        deviceId: z.string().min(3).max(128),
        deviceName: z.string().min(1).max(160),
        platform: z.string().min(1).max(32),
      }))
      .mutation(({ input }) => acceptDeviceSession(input)),

    authorizeAction: publicProcedure
      .input(z.object({
        sessionId: z.string().min(3).max(64),
        sessionToken: z.string().min(40).max(128),
        capability: z.enum(DEVICE_CAPABILITIES),
        action: z.string().min(1).max(1000),
      }))
      .mutation(({ input }) => authorizeDeviceAction(input)),

    endSession: publicProcedure
      .input(z.object({ sessionId: z.string().min(3).max(64), sessionToken: z.string().min(40).max(128) }))
      .mutation(({ input }) => endDeviceSession(input)),

    revokeSession: adminProcedure
      .input(z.object({ sessionId: z.string().min(3).max(64) }))
      .mutation(({ ctx, input }) => revokeDeviceSession(ctx.user.openId, input.sessionId)),
  }),

  policies: router({
    list: adminProcedure.query(({ ctx }) => listOwnerPolicies(ctx.user.openId)),
    save: adminProcedure
      .input(z.object({
        id: z.number().int().positive().optional(),
        policyKey: z.string().trim().min(2).max(80).regex(/^[a-z0-9._-]+$/),
        label: z.string().trim().min(1).max(160),
        description: z.string().trim().min(1).max(2000),
        enabled: z.boolean(),
      }))
      .mutation(({ ctx, input }) => upsertOwnerPolicy({ ...input, ownerOpenId: ctx.user.openId })),
    remove: adminProcedure
      .input(z.object({ id: z.number().int().positive() }))
      .mutation(({ ctx, input }) => deleteOwnerPolicy(ctx.user.openId, input.id)),
  }),

  integrations: router({
    connections: router({
      list: adminProcedure.query(({ ctx }) => listExternalConnections(ctx.user.openId)),
      test: adminProcedure
        .input(z.object({ id: z.number().int().positive() }))
        .mutation(async ({ ctx, input }) => {
          const connection = await getExternalConnection(ctx.user.openId, input.id);
          const result = await testExternalConnection(connection);
          await addIntegrationAuditLog({
            ownerOpenId: ctx.user.openId,
            entityType: "connection",
            entityId: input.id,
            action: "connection.tested",
            result: result.reachable ? "allowed" : "failed",
            details: result.reachable ? "نجح اختبار الاتصال دون تسجيل السر أو نتيجة بيانات خارجية." : "فشل اختبار الاتصال؛ تم تسجيل الحالة فقط دون تسجيل تفاصيل سرية.",
          });
          return result;
        }),
      save: adminProcedure.input(z.object({
        id: z.number().int().positive().optional(),
        label: z.string().trim().min(1).max(120),
        kind: z.enum(["mysql", "postgres", "supabase", "rest_api"]),
        host: z.string().trim().min(1).max(255).refine((value) => !secretLikeText.test(value), "لا تضع مفتاحًا أو كلمة مرور في العنوان"),
        databaseName: z.string().trim().max(160).optional(),
        username: z.string().trim().max(160).optional(),
        secretRef: secretRefSchema,
        sslRequired: z.boolean().default(true),
        enabled: z.boolean().default(true),
      })).mutation(async ({ ctx, input }) => {
        const result = await upsertExternalConnection({ ...input, ownerOpenId: ctx.user.openId, sslRequired: input.sslRequired ? 1 : 0, enabled: input.enabled ? 1 : 0 });
        await addIntegrationAuditLog({ ownerOpenId: ctx.user.openId, entityType: "connection", entityId: result.id, action: input.id ? "connection.updated" : "connection.created", result: "allowed", details: "تم حفظ بيانات الاتصال ومرجع السر فقط دون قيمة سرية." });
        return result;
      }),
      remove: adminProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
        const result = await deleteExternalConnection(ctx.user.openId, input.id);
        await addIntegrationAuditLog({ ownerOpenId: ctx.user.openId, entityType: "connection", entityId: input.id, action: "connection.removed", result: "allowed", details: "تم حذف تعريف الاتصال؛ لم تُقرأ قيمة السر." });
        return result;
      }),
    }),
    apiKeys: router({
      list: adminProcedure.query(({ ctx }) => listApiKeyRefs(ctx.user.openId)),
      register: adminProcedure.input(z.object({ provider: z.string().trim().min(1).max(120), label: z.string().trim().min(1).max(120), secretRef: secretRefSchema, scopes: z.array(z.string().trim().min(1).max(80)).max(40) })).mutation(async ({ ctx, input }) => {
        const result = await createApiKeyRef({ ownerOpenId: ctx.user.openId, provider: input.provider, label: input.label, secretRef: input.secretRef, scopes: JSON.stringify(input.scopes), status: "unconfigured", fingerprint: null });
        await addIntegrationAuditLog({ ownerOpenId: ctx.user.openId, entityType: "api_key", entityId: result.id, action: "api_key.registered", result: "allowed", details: "تم تسجيل مرجع المفتاح فقط؛ القيمة نفسها تُدار خارج قاعدة البيانات." });
        return result;
      }),
      revoke: adminProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
        const result = await revokeApiKeyRef(ctx.user.openId, input.id);
        await addIntegrationAuditLog({ ownerOpenId: ctx.user.openId, entityType: "api_key", entityId: input.id, action: "api_key.revoked", result: "allowed", details: "تم إلغاء مرجع المفتاح دون إظهار قيمته." });
        return result;
      }),
    }),
    fileChanges: router({
      list: adminProcedure.query(({ ctx }) => listFileChangeRequests(ctx.user.openId)),
      propose: adminProcedure.input(z.object({ filePath: filePathSchema, summary: z.string().trim().min(1).max(500), patch: z.string().min(10).max(120_000), risk: z.enum(["low", "medium", "high"]) })).mutation(async ({ ctx, input }) => {
        if (secretLikeText.test(input.patch) || secretLikeText.test(input.summary)) throw new Error("لا يمكن حفظ Patch يحتوي أسرارًا أو مفاتيح");
        const result = await createFileChangeRequest({ ownerOpenId: ctx.user.openId, filePath: input.filePath, summary: input.summary, patch: input.patch, risk: input.risk, status: "awaiting_approval" });
        await addIntegrationAuditLog({ ownerOpenId: ctx.user.openId, entityType: "file_change", entityId: result.id, action: "file_change.proposed", result: "allowed", details: "تم حفظ Patch للمراجعة دون تطبيق مباشر." });
        return result;
      }),
      approve: adminProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
        const result = await updateFileChangeRequest(ctx.user.openId, input.id, "approved", new Date());
        await addIntegrationAuditLog({ ownerOpenId: ctx.user.openId, entityType: "file_change", entityId: input.id, action: "file_change.approved", result: "allowed", details: "اعتمد المالك Patch؛ منفذ Git/النشر الخارجي غير موصول داخل التطبيق." });
        return result;
      }),
      applyPatch: adminProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
        await updateFileChangeRequest(ctx.user.openId, input.id, "execution_unavailable");
        await addIntegrationAuditLog({ ownerOpenId: ctx.user.openId, entityType: "file_change", entityId: input.id, action: "file_change.apply", result: "denied", details: "تم منع التطبيق المباشر؛ لا توجد صلاحية Git أو Shell داخل التطبيق المنشور." });
        return { applied: false as const, reason: "execution_unavailable" as const };
      }),
      cancel: adminProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
        const result = await updateFileChangeRequest(ctx.user.openId, input.id, "cancelled");
        await addIntegrationAuditLog({ ownerOpenId: ctx.user.openId, entityType: "file_change", entityId: input.id, action: "file_change.cancelled", result: "allowed", details: "ألغى المالك Patch." });
        return result;
      }),
    }),
  }),

  rootManager: router({
    list: adminProcedure.query(({ ctx }) => listRootChangeRequests(ctx.user.openId)),
    plan: adminProcedure
      .input(z.object({ requestText: z.string().trim().min(5).max(4000) }))
      .mutation(async ({ ctx, input }) => {
        if (secretLikeText.test(input.requestText)) throw new Error("لا ترسل أسرارًا أو مفاتيح إلى Root Manager");
        const planResult = await invokeLLM({
          messages: [
            { role: "system", content: "أنت مخطط Root Manager آمن. لا تنفذ كودًا ولا تقترح أوامر Shell. حوّل طلب المالك إلى خطة تغيير قابلة للمراجعة. لا تضع أسرارًا، ولا مسارات خارج مشروع ZANOX، ولا تدّعِ أن التعديل طُبّق أو نُشر. صنّف الخطورة: low لتغيير واجهة أو نص، medium لتغيير خادم أو API، high للمصادقة أو قاعدة البيانات أو النشر." },
            { role: "user", content: input.requestText },
          ],
          max_tokens: 1200,
          outputSchema: {
            name: "root_change_plan",
            strict: true,
            schema: {
              type: "object",
              additionalProperties: false,
              properties: {
                summary: { type: "string" },
                affectedFiles: { type: "array", items: { type: "string" } },
                changes: { type: "array", items: { type: "string" } },
                validation: { type: "array", items: { type: "string" } },
                risk: { type: "string", enum: ["low", "medium", "high"] },
                requiresConfirmation: { type: "boolean" },
              },
              required: ["summary", "affectedFiles", "changes", "validation", "risk", "requiresConfirmation"],
            },
          },
        });
        const plan = planResult.choices?.[0]?.message?.content;
        if (typeof plan !== "string" || !plan.trim()) throw new Error("تعذر إنشاء خطة Root Manager");
        let parsed: z.infer<typeof rootPlanSchema>;
        try {
          parsed = rootPlanSchema.parse(JSON.parse(plan));
        } catch {
          throw new Error("خطة Root Manager لم ترجع بصيغة منظمة");
        }
        assertSafeRootPlan(parsed);
        const record = await createRootChangeRequest({ ownerOpenId: ctx.user.openId, requestText: input.requestText, summary: parsed.summary, affectedFiles: JSON.stringify(parsed.affectedFiles), planJson: JSON.stringify(parsed), risk: parsed.risk, status: "awaiting_approval" });
        await addRootAuditLog({ ownerOpenId: ctx.user.openId, requestId: record.id, action: "plan.created", result: "allowed", details: "تم إنشاء خطة تغيير للمراجعة دون تطبيق أو نشر." });
        return { ...record, plan: parsed, status: "awaiting_approval" as const };
      }),
    approve: adminProcedure
      .input(z.object({ id: z.number().int().positive() }))
      .mutation(async ({ ctx, input }) => {
        await updateRootChangeRequest(ctx.user.openId, input.id, "approved", new Date());
        await addRootAuditLog({ ownerOpenId: ctx.user.openId, requestId: input.id, action: "plan.approved", result: "allowed", details: "وافق المالك على الخطة؛ لم يتم تطبيق التعديل أو نشره تلقائيًا." });
        return { approved: true as const, execution: "not_connected" as const };
      }),
    cancel: adminProcedure
      .input(z.object({ id: z.number().int().positive() }))
      .mutation(async ({ ctx, input }) => {
        await updateRootChangeRequest(ctx.user.openId, input.id, "cancelled");
        await addRootAuditLog({ ownerOpenId: ctx.user.openId, requestId: input.id, action: "plan.cancelled", result: "allowed", details: "ألغى المالك خطة Root Manager." });
        return { cancelled: true as const };
      }),
  }),

  // TODO: add feature routers here, e.g.
  // todo: router({
  //   list: protectedProcedure.query(({ ctx }) =>
  //     db.getUserTodos(ctx.user.id)
  //   ),
  // }),
});

export type AppRouter = typeof appRouter;
