import { ScrollViewStyleReset, useServerDocumentContext } from "expo-router/html";

export default function Root({ children }: { children: React.ReactNode }) {
  const { bodyAttributes, bodyNodes, htmlAttributes, headNodes } = useServerDocumentContext();

  return (
    <html lang="ar" dir="rtl" {...htmlAttributes}>
      <head>
        <meta charSet="utf-8" />
        <meta httpEquiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="theme-color" content="#0A0D1F" />
        <meta name="description" content="ZANOX — منصة المحادثة والبرمجة والتفاعل الصوتي." />
        <meta property="og:title" content="ZANOX — منصة التحكم الذكية" />
        <meta property="og:description" content="محادثة وأدوات متعددة تحت سياسات يحددها المالك." />
        <meta name="application-name" content="ZANOX" />
        <link rel="manifest" href="/manifest.json" />
        <ScrollViewStyleReset />
        {headNodes}
        <title>ZANOX — منصة التحكم الذكية</title>
      </head>
      <body {...bodyAttributes}>
        {children}
        {bodyNodes}
      </body>
    </html>
  );
}
