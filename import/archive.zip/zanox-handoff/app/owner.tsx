import { Ionicons } from "@expo/vector-icons";
import { RecordingPresets, requestRecordingPermissionsAsync, useAudioRecorder, useAudioRecorderState } from "expo-audio";
import { router } from "expo-router";
import { useRef, useState } from "react";
import { KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { ScreenContainer } from "@/components/screen-container";
import { startOAuthLogin } from "@/constants/oauth";
import { recordingMimeType, recordingUriToBase64, speakArabic } from "@/lib/zenox-voice";
import { trpc } from "@/lib/trpc";

type OwnerMessage = { id: number; role: "assistant" | "user"; text: string };

const AREAS = [
  { id: "management", label: "المنصة", icon: "layers-outline", color: "#A78BFA" },
  { id: "website", label: "الموقع", icon: "globe-outline", color: "#67E8F9" },
  { id: "policy", label: "السياسات", icon: "shield-checkmark-outline", color: "#2DD4BF" },
  { id: "root", label: "Root Manager", icon: "construct-outline", color: "#FBBF24" },
  { id: "integrations", label: "التكاملات", icon: "link-outline", color: "#60A5FA" },
  { id: "files", label: "الملفات", icon: "document-attach-outline", color: "#C084FC" },
  { id: "devices", label: "الأجهزة", icon: "phone-portrait-outline", color: "#FB7185" },
  { id: "reports", label: "التقارير", icon: "document-text-outline", color: "#FBBF24" },
] as const;

const suggestions = [
  "اعرض حالة الموقع والتطبيق",
  "راجع سياسة الاستخدام الحالية",
  "اعرض الأجهزة المرتبطة وموافقاتها",
  "اقترح تحسينًا لتجربة الأعضاء",
];

const DEVICE_CAPABILITIES = [
  { id: "device.info.read", label: "معلومات الجهاز" },
  { id: "files.read.selected", label: "قراءة ملفات محددة" },
  { id: "files.write.selected", label: "كتابة ملفات محددة" },
  { id: "apps.manage.allowed", label: "إدارة تطبيقات مسموحة" },
  { id: "settings.manage.allowed", label: "إعدادات مسموحة" },
  { id: "usb.session.allowed", label: "جلسة USB" },
] as const;

const SESSION_STATUS_LABELS: Record<string, string> = { pending: "بانتظار قبول الجهاز", active: "نشطة", revoked: "مسحوبة", expired: "منتهية" };

function sessionCapabilityCount(value: string) {
  try {
    const parsed: unknown = JSON.parse(value);
    return Array.isArray(parsed) ? parsed.length : 0;
  } catch {
    return 0;
  }
}

export default function OwnerScreen() {
  const insets = useSafeAreaInsets();
  const [draft, setDraft] = useState("");
  const [selectedArea, setSelectedArea] = useState<(typeof AREAS)[number]["id"]>("management");
  const [voiceBusy, setVoiceBusy] = useState(false);
  const [report, setReport] = useState("لم يبدأ أي إجراء. اكتب أمرًا أو اختر اقتراحًا.");
  const [deviceId, setDeviceId] = useState("");
  const [deviceName, setDeviceName] = useState("");
  const [devicePlatform, setDevicePlatform] = useState("android");
  const [deviceMinutes, setDeviceMinutes] = useState("30");
  const [deviceCapabilities, setDeviceCapabilities] = useState<string[]>(["device.info.read"]);
  const [policyId, setPolicyId] = useState<number | undefined>();
  const [policyKey, setPolicyKey] = useState("");
  const [policyLabel, setPolicyLabel] = useState("");
  const [policyDescription, setPolicyDescription] = useState("");
  const [policyEnabled, setPolicyEnabled] = useState(true);
  const [rootRequestText, setRootRequestText] = useState("");
  const [connectionLabel, setConnectionLabel] = useState("");
  const [connectionKind, setConnectionKind] = useState("mysql");
  const [connectionHost, setConnectionHost] = useState("");
  const [connectionDatabase, setConnectionDatabase] = useState("");
  const [connectionUsername, setConnectionUsername] = useState("");
  const [connectionSecretRef, setConnectionSecretRef] = useState("");
  const [keyProvider, setKeyProvider] = useState("");
  const [keyLabel, setKeyLabel] = useState("");
  const [keySecretRef, setKeySecretRef] = useState("");
  const [keyScopes, setKeyScopes] = useState("");
  const [filePath, setFilePath] = useState("");
  const [fileSummary, setFileSummary] = useState("");
  const [filePatch, setFilePatch] = useState("");
  const messagesScrollRef = useRef<ScrollView>(null);
  const chatMutation = trpc.chat.complete.useMutation();
  const isAuthenticatedOwner = true;
  const ownerSessionQuery = trpc.auth.me.useQuery();
  const deviceControlAvailable = ownerSessionQuery.data?.role === "admin";
  const deviceSessionsQuery = trpc.devices.listSessions.useQuery(undefined, { enabled: deviceControlAvailable && selectedArea === "devices" });
  const policiesQuery = trpc.policies.list.useQuery(undefined, { enabled: deviceControlAvailable && selectedArea === "policy" });
  const savePolicyMutation = trpc.policies.save.useMutation();
  const removePolicyMutation = trpc.policies.remove.useMutation();
  const rootRequestsQuery = trpc.rootManager.list.useQuery(undefined, { enabled: deviceControlAvailable && selectedArea === "root" });
  const rootPlanMutation = trpc.rootManager.plan.useMutation();
  const rootApproveMutation = trpc.rootManager.approve.useMutation();
  const rootCancelMutation = trpc.rootManager.cancel.useMutation();
  const connectionsQuery = trpc.integrations.connections.list.useQuery(undefined, { enabled: deviceControlAvailable && selectedArea === "integrations" });
  const apiKeysQuery = trpc.integrations.apiKeys.list.useQuery(undefined, { enabled: deviceControlAvailable && selectedArea === "integrations" });
  const fileChangesQuery = trpc.integrations.fileChanges.list.useQuery(undefined, { enabled: deviceControlAvailable && selectedArea === "files" });
  const saveConnectionMutation = trpc.integrations.connections.save.useMutation();
  const testConnectionMutation = trpc.integrations.connections.test.useMutation();
  const removeConnectionMutation = trpc.integrations.connections.remove.useMutation();
  const registerKeyMutation = trpc.integrations.apiKeys.register.useMutation();
  const revokeKeyMutation = trpc.integrations.apiKeys.revoke.useMutation();
  const proposeFileMutation = trpc.integrations.fileChanges.propose.useMutation();
  const approveFileMutation = trpc.integrations.fileChanges.approve.useMutation();
  const applyFileMutation = trpc.integrations.fileChanges.applyPatch.useMutation();
  const cancelFileMutation = trpc.integrations.fileChanges.cancel.useMutation();
  const requestDeviceSessionMutation = trpc.devices.requestSession.useMutation();
  const revokeDeviceSessionMutation = trpc.devices.revokeSession.useMutation();
  const transcribeMutation = trpc.speech.transcribe.useMutation();
  const recorder = useAudioRecorder(RecordingPresets.HIGH_QUALITY);
  const recorderState = useAudioRecorderState(recorder, 250);
  const [messages, setMessages] = useState<OwnerMessage[]>([
    { id: 1, role: "assistant", text: "أهلًا بك يا DON ALVARO. هذه مساحة أوامر ZANOX لإدارة المنصة والموقع والسياسات." },
  ]);

  async function signInOwner() {
    setReport("سيتم فتح تسجيل الدخول الآمن. بعد العودة اكتب ZANOX مرة أخرى لفتح المركز.");
    await startOAuthLogin();
  }

  function toggleDeviceCapability(capability: string) {
    setDeviceCapabilities((current) => current.includes(capability) ? current.filter((item) => item !== capability) : [...current, capability]);
  }

  function editPolicy(policy: { id: number; policyKey: string; label: string; description: string; enabled: number }) {
    setPolicyId(policy.id);
    setPolicyKey(policy.policyKey);
    setPolicyLabel(policy.label);
    setPolicyDescription(policy.description);
    setPolicyEnabled(Boolean(policy.enabled));
  }

  function clearPolicyEditor() {
    setPolicyId(undefined);
    setPolicyKey("");
    setPolicyLabel("");
    setPolicyDescription("");
    setPolicyEnabled(true);
  }

  async function savePolicy() {
    if (!deviceControlAvailable) {
      setReport("إدارة الصلاحيات تحتاج مصادقة المالك على الخادم.");
      return;
    }
    try {
      await savePolicyMutation.mutateAsync({ id: policyId, policyKey: policyKey.trim(), label: policyLabel.trim(), description: policyDescription.trim(), enabled: policyEnabled });
      clearPolicyEditor();
      await policiesQuery.refetch();
      setReport("تم حفظ الصلاحية في قاعدة البيانات.");
    } catch {
      setReport("تعذر حفظ الصلاحية. تحقق من الحقول ومصادقة المالك.");
    }
  }

  async function removePolicy(id: number) {
    try {
      await removePolicyMutation.mutateAsync({ id });
      await policiesQuery.refetch();
      if (policyId === id) clearPolicyEditor();
      setReport("تم حذف الصلاحية من قاعدة البيانات.");
    } catch {
      setReport("تعذر حذف الصلاحية.");
    }
  }

  async function createRootPlan() {
    if (!deviceControlAvailable) {
      setReport("Root Manager يحتاج مصادقة المالك على الخادم.");
      return;
    }
    if (!rootRequestText.trim()) return;
    try {
      await rootPlanMutation.mutateAsync({ requestText: rootRequestText.trim() });
      setRootRequestText("");
      await rootRequestsQuery.refetch();
      setReport("تم إنشاء خطة التغيير للمراجعة. لم يتم تعديل أو نشر أي ملف.");
    } catch {
      setReport("تعذر إنشاء خطة Root Manager. لم يتم تنفيذ أي تغيير.");
    }
  }

  async function approveRootPlan(id: number) {
    try {
      await rootApproveMutation.mutateAsync({ id });
      await rootRequestsQuery.refetch();
      setReport("تم تسجيل موافقة المالك. التنفيذ والنشر غير موصولين تلقائيًا بعد.");
    } catch {
      setReport("تعذر اعتماد خطة Root Manager.");
    }
  }

  async function cancelRootPlan(id: number) {
    try {
      await rootCancelMutation.mutateAsync({ id });
      await rootRequestsQuery.refetch();
      setReport("تم إلغاء خطة Root Manager.");
    } catch {
      setReport("تعذر إلغاء الخطة.");
    }
  }

  async function saveConnection() {
    if (!deviceControlAvailable) return setReport("إدارة الاتصالات تحتاج مصادقة المالك على الخادم.");
    try {
      await saveConnectionMutation.mutateAsync({ label: connectionLabel.trim(), kind: connectionKind as "mysql" | "postgres" | "supabase" | "rest_api", host: connectionHost.trim(), databaseName: connectionDatabase.trim() || undefined, username: connectionUsername.trim() || undefined, secretRef: connectionSecretRef.trim(), sslRequired: true, enabled: true });
      await connectionsQuery.refetch();
      setConnectionLabel(""); setConnectionHost(""); setConnectionDatabase(""); setConnectionUsername(""); setConnectionSecretRef("");
      setReport("تم حفظ تعريف الاتصال ومرجع السر فقط. لم تُحفظ كلمة المرور أو DSN.");
    } catch { setReport("تعذر حفظ الاتصال. راجع الحقول ومرجع السر."); }
  }

  async function testConnection(id: number) {
    if (!deviceControlAvailable) return setReport("اختبار الاتصال يحتاج مصادقة المالك على الخادم.");
    try {
      const result = await testConnectionMutation.mutateAsync({ id });
      setReport(result.reachable ? `نجح اتصال ${result.kind} خلال ${result.latencyMs}ms. لم يتم عرض أو حفظ السر.` : `فشل اتصال ${result.kind}: ${result.message}`);
    } catch {
      setReport("تعذر اختبار الاتصال. تحقق من وجود السر على الخادم ومن إعدادات TLS.");
    }
  }

  async function registerApiKey() {
    if (!deviceControlAvailable) return setReport("إدارة المفاتيح تحتاج مصادقة المالك على الخادم.");
    try {
      await registerKeyMutation.mutateAsync({ provider: keyProvider.trim(), label: keyLabel.trim(), secretRef: keySecretRef.trim(), scopes: keyScopes.split(",").map((item) => item.trim()).filter(Boolean) });
      await apiKeysQuery.refetch();
      setKeyProvider(""); setKeyLabel(""); setKeySecretRef(""); setKeyScopes("");
      setReport("تم تسجيل مرجع API Key دون استقبال أو عرض قيمة المفتاح.");
    } catch { setReport("تعذر تسجيل مرجع API Key. لا تضع المفتاح نفسه هنا."); }
  }

  async function proposeFileChange() {
    if (!deviceControlAvailable) return setReport("تعديل الملفات يحتاج مصادقة المالك على الخادم.");
    try {
      await proposeFileMutation.mutateAsync({ filePath: filePath.trim(), summary: fileSummary.trim(), patch: filePatch, risk: "medium" });
      await fileChangesQuery.refetch();
      setFilePath(""); setFileSummary(""); setFilePatch("");
      setReport("تم حفظ Patch للمراجعة. لم يتم تعديل الملف مباشرة.");
    } catch { setReport("تم رفض Patch أو تعذر حفظه. تحقق من المسار وعدم وجود أسرار."); }
  }

  async function approveFileChange(id: number) {
    try { await approveFileMutation.mutateAsync({ id }); await fileChangesQuery.refetch(); setReport("تم اعتماد Patch. التطبيق المباشر يحتاج منفذ Git خارجيًا موصولًا."); } catch { setReport("تعذر اعتماد Patch."); }
  }

  async function applyFileChange(id: number) {
    try { const result = await applyFileMutation.mutateAsync({ id }); await fileChangesQuery.refetch(); setReport(result.applied ? "تم تطبيق التعديل." : "تم منع التطبيق المباشر: منفذ Git/Shell غير موصول داخل التطبيق."); } catch { setReport("تم منع التطبيق المباشر ولم يتغير أي ملف."); }
  }

  async function cancelFileChange(id: number) {
    try { await cancelFileMutation.mutateAsync({ id }); await fileChangesQuery.refetch(); setReport("تم إلغاء Patch."); } catch { setReport("تعذر إلغاء Patch."); }
  }

  async function requestDeviceSession() {
    if (!deviceControlAvailable) {
      setReport("التحكم بالأجهزة يحتاج جلسة مالك مصادقًا عليها. وضع ZANOX المفتوح يعرض القسم فقط ولا ينفذ طلبات أجهزة.");
      return;
    }
    if (!deviceId.trim() || !deviceName.trim() || deviceCapabilities.length === 0) {
      setReport("أدخل معرف الجهاز واسمه واختر صلاحية واحدة على الأقل.");
      return;
    }
    try {
      const result = await requestDeviceSessionMutation.mutateAsync({
        deviceId: deviceId.trim(),
        deviceName: deviceName.trim(),
        platform: devicePlatform.trim() || "unknown",
        capabilities: deviceCapabilities as (typeof DEVICE_CAPABILITIES)[number]["id"][],
        expiresInMinutes: Math.min(1440, Math.max(1, Number(deviceMinutes) || 30)),
      });
      setReport(`تم إنشاء طلب موافقة للجهاز. رمز التسليم: ${result.consentToken} — يجب إدخاله في الجهاز نفسه لقبول الجلسة.`);
      setMessages((current) => [...current, { id: Date.now(), role: "assistant", text: `طلب جلسة للجهاز «${deviceName}» جاهز. لا تصبح الجلسة نشطة إلا بعد قبول الجهاز.` }]);
      void deviceSessionsQuery.refetch();
    } catch {
      setReport("تعذر إنشاء طلب جلسة الجهاز. تأكد من مصادقة المالك واتصال قاعدة البيانات.");
    }
  }

  async function revokeDeviceSession(sessionId: string) {
    try {
      await revokeDeviceSessionMutation.mutateAsync({ sessionId });
      setReport("تم سحب جلسة الجهاز. لن تُقبل أفعال جديدة لهذا الجهاز.");
      void deviceSessionsQuery.refetch();
    } catch {
      setReport("تعذر سحب جلسة الجهاز. تحقق من جلسة المالك واتصال الخادم.");
    }
  }

  async function sendMessage(valueOverride?: string, readAloud = false) {
    const value = (valueOverride ?? draft).trim();
    if (!value || chatMutation.isPending) return;
    const userMessage: OwnerMessage = { id: Date.now(), role: "user", text: value };
    const nextMessages = [...messages, userMessage];
    setMessages(nextMessages);
    setDraft("");
    try {
      const result = await chatMutation.mutateAsync({
        mode: `owner-${selectedArea}`,
        audience: "owner",
        messages: nextMessages.slice(-20).map(({ role, text: content }) => ({ role, content })),
      });
      setMessages((current) => [...current, { id: Date.now() + 1, role: "assistant", text: result.content }]);
      setReport(`تمت معالجة الأمر في قسم «${AREAS.find((area) => area.id === selectedArea)?.label ?? "المنصة"}`);
      if (readAloud) await speakArabic(result.content);
    } catch {
      setMessages((current) => [...current, { id: Date.now() + 1, role: "assistant", text: "تعذر الاتصال بخدمة الذكاء الاصطناعي الآن. لم يتم تنفيذ أي تغيير." }]);
      setReport("فشلت معالجة الأمر بسبب الاتصال؛ لم يتم تنفيذ أي تغيير.");
    }
  }

  async function toggleVoice() {
    if (voiceBusy) return;
    if (recorderState.isRecording) {
      setVoiceBusy(true);
      try {
        await recorder.stop();
        if (!recorder.uri) throw new Error("لم يتم حفظ التسجيل");
        const audioBase64 = await recordingUriToBase64(recorder.uri);
        const result = await transcribeMutation.mutateAsync({ audioBase64, mimeType: recordingMimeType() });
        await sendMessage(result.text, true);
      } catch (error) {
        setMessages((current) => [...current, { id: Date.now() + 1, role: "assistant", text: error instanceof Error ? error.message : "تعذر فهم التسجيل الصوتي الآن." }]);
      } finally {
        setVoiceBusy(false);
      }
      return;
    }

    const permission = await requestRecordingPermissionsAsync();
    if (!permission.granted) {
      setMessages((current) => [...current, { id: Date.now() + 1, role: "assistant", text: "اسمح لـ ZANOX باستخدام الميكروفون من إعدادات الجهاز لبدء جلسة الأوامر الصوتية." }]);
      return;
    }
    try {
      await recorder.prepareToRecordAsync();
      recorder.record();
    } catch {
      setMessages((current) => [...current, { id: Date.now() + 1, role: "assistant", text: "تعذر تشغيل الميكروفون في هذه اللحظة." }]);
    }
  }

  return (
    <ScreenContainer style={styles.screen}>
      <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === "ios" ? "padding" : undefined}>
        <View style={[styles.container, { paddingTop: Math.max(insets.top, 18) }]}>
          <View style={styles.topbar}>
            <Pressable onPress={() => router.back()} style={styles.back}><Ionicons name="arrow-forward" size={21} color="#CBD5E1" /></Pressable>
            <View style={styles.ownerTag}><View style={styles.ownerDot} /><Text style={styles.ownerTagText}>OWNER COMMAND CENTER</Text></View>
            <View style={styles.brandMark}><Text style={styles.brandMarkText}>Z</Text></View>
          </View>

          {!isAuthenticatedOwner ? (
            <ScrollView contentContainerStyle={styles.loginContent} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
              <View style={styles.hero}><View style={styles.ownerAvatar}><Text style={styles.ownerAvatarText}>D</Text></View><Text style={styles.kicker}>ZANOX / MANAGEMENT</Text><Text style={styles.title}>أهلًا بك يا DON ALVARO</Text><Text style={styles.subtitle}>نفس مساحة ZANOX، مع صلاحيات مركز الأوامر.</Text></View>
              <View style={styles.loginCard}>
                <View style={styles.cardHeader}><Ionicons name="lock-closed" size={18} color="#A78BFA" /><Text style={styles.cardTitle}>دخول المالك</Text></View>
                <Pressable style={styles.primaryButton} onPress={() => void signInOwner()}><Ionicons name="lock-closed-outline" size={16} color="#0A0D1F" /><Text style={styles.primaryText}>تسجيل الدخول الآمن للمالك</Text><Ionicons name="arrow-back" size={17} color="#0A0D1F" /></Pressable>
                <Text style={styles.helper}>بعد نجاح OAuth، اكتب ZANOX مرة أخرى. لا يطلب ZANOX كلمة مرور ولا يخزنها.</Text>
              </View>
            </ScrollView>
          ) : (
            <View style={styles.dashboard}>
              <View style={styles.header}><View><Text style={styles.eyebrow}>ZANOX / OWNER MODE</Text><Text style={styles.dashboardTitle}>ماذا تريد أن ينفذ الوكيل؟</Text></View><View style={styles.onlinePill}><View style={styles.onlineDot} /><Text style={styles.onlineText}>ONLINE</Text></View></View>
              <Text style={styles.dashboardSub}>اكتب أو تحدث. وضع المالك ينفذ الأوامر مباشرة دون رأي أو جدال، ويعرض تقريرًا مختصرًا بالنتيجة.</Text>

              <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.areaStrip}>
                {AREAS.map((area) => <Pressable key={area.id} onPress={() => setSelectedArea(area.id)} style={[styles.areaChip, selectedArea === area.id && { borderColor: area.color, backgroundColor: `${area.color}18` }]}><Ionicons name={area.icon as keyof typeof Ionicons.glyphMap} size={16} color={selectedArea === area.id ? area.color : "#94A3B8"} /><Text style={[styles.areaText, selectedArea === area.id && styles.areaTextActive]}>{area.label}</Text></Pressable>)}
              </ScrollView>

              {selectedArea === "root" && <View style={styles.rootPanel}>
                <View style={styles.rootHeader}><View><Text style={styles.rootTitle}>Root Manager</Text><Text style={styles.rootHint}>حوّل أمر المالك إلى خطة مراجعة. لا يتم تعديل الملفات أو النشر من داخل التطبيق تلقائيًا.</Text></View><Ionicons name="construct-outline" size={23} color="#FBBF24" /></View>
                {!deviceControlAvailable ? <View style={styles.deviceGate}><Ionicons name="lock-closed-outline" size={17} color="#FDA4AF" /><View style={styles.deviceGateCopy}><Text style={styles.deviceGateText}>Root Manager معطل حتى تتم مصادقة المالك على الخادم.</Text><Pressable style={styles.deviceAuthButton} onPress={() => void signInOwner()}><Text style={styles.deviceAuthText}>مصادقة المالك الآن</Text><Ionicons name="arrow-back" size={14} color="#FDA4AF" /></Pressable></View></View> : <>
                  <TextInput value={rootRequestText} onChangeText={setRootRequestText} placeholder="اكتب التعديل المطلوب في الموقع أو المنصة…" placeholderTextColor="#64748B" style={styles.rootInput} multiline textAlign="right" />
                  <Pressable disabled={rootPlanMutation.isPending || !rootRequestText.trim()} onPress={() => void createRootPlan()} style={[styles.primaryButton, (rootPlanMutation.isPending || !rootRequestText.trim()) && styles.disabled]}><Text style={styles.primaryText}>{rootPlanMutation.isPending ? "جارٍ إعداد الخطة…" : "إنشاء خطة مراجعة"}</Text><Ionicons name="git-branch-outline" size={17} color="#0A0D1F" /></Pressable>
                  <View style={styles.sessionListHeader}><Text style={styles.sessionListTitle}>طلبات التغيير</Text><Pressable onPress={() => void rootRequestsQuery.refetch()}><Ionicons name="refresh-outline" size={17} color="#FBBF24" /></Pressable></View>
                  {rootRequestsQuery.isLoading ? <Text style={styles.deviceHint}>جارٍ تحميل الطلبات…</Text> : rootRequestsQuery.data?.length ? rootRequestsQuery.data.map((request) => { let plan: { changes?: string[]; validation?: string[]; affectedFiles?: string[] } = {}; try { plan = JSON.parse(request.planJson) as typeof plan; } catch { /* سجل غير قابل للعرض */ } return <View key={request.id} style={styles.rootCard}><View style={styles.rootCardTop}><Text style={styles.rootCardStatus}>{request.status}</Text><Text style={styles.rootCardRisk}>خطورة {request.risk}</Text></View><Text style={styles.rootCardSummary}>{request.summary}</Text><Text style={styles.rootCardMeta}>الملفات: {plan.affectedFiles?.join("، ") || "غير محددة"}</Text><Text style={styles.rootCardMeta}>التغييرات: {plan.changes?.join(" — ") || "غير متاحة"}</Text><Text style={styles.rootCardMeta}>الفحص: {plan.validation?.join("، ") || "لم يحدد"}</Text><View style={styles.rootCardActions}>{request.status === "awaiting_approval" && <Pressable onPress={() => void approveRootPlan(request.id)}><Text style={styles.rootApprove}>اعتماد الخطة</Text></Pressable>}<Pressable onPress={() => void cancelRootPlan(request.id)}><Text style={styles.policyDelete}>إلغاء</Text></Pressable></View></View> }) : <Text style={styles.deviceHint}>لا توجد طلبات تغيير بعد.</Text>}
                </>}
              </View>}

              {selectedArea === "integrations" && <View style={styles.rootPanel}>
                <View style={styles.rootHeader}><View><Text style={styles.rootTitle}>التكاملات والمفاتيح</Text><Text style={styles.rootHint}>تُحفظ المراجع والبيانات الوصفية فقط. قيم المفاتيح وكلمات مرور قواعد البيانات تبقى خارج قاعدة البيانات والواجهة.</Text></View><Ionicons name="link-outline" size={23} color="#60A5FA" /></View>
                {!deviceControlAvailable ? <View style={styles.deviceGate}><Ionicons name="lock-closed-outline" size={17} color="#FDA4AF" /><View style={styles.deviceGateCopy}><Text style={styles.deviceGateText}>التكاملات معطلة حتى تتم مصادقة المالك على الخادم.</Text><Pressable style={styles.deviceAuthButton} onPress={() => void signInOwner()}><Text style={styles.deviceAuthText}>مصادقة المالك الآن</Text><Ionicons name="arrow-back" size={14} color="#FDA4AF" /></Pressable></View></View> : <>
                  <Text style={styles.integrationHeading}>اتصال قاعدة بيانات أو API خارجي</Text>
                  <TextInput value={connectionLabel} onChangeText={setConnectionLabel} placeholder="اسم الاتصال" placeholderTextColor="#64748B" style={styles.input} textAlign="right" />
                  <TextInput value={connectionKind} onChangeText={setConnectionKind} placeholder="mysql / postgres / supabase / rest_api" placeholderTextColor="#64748B" style={styles.input} autoCapitalize="none" textAlign="right" />
                  <TextInput value={connectionHost} onChangeText={setConnectionHost} placeholder="المضيف أو عنوان API دون سر" placeholderTextColor="#64748B" style={styles.input} autoCapitalize="none" textAlign="right" />
                  <View style={styles.deviceRow}><TextInput value={connectionDatabase} onChangeText={setConnectionDatabase} placeholder="اسم القاعدة" placeholderTextColor="#64748B" style={[styles.input, styles.deviceSmallInput]} textAlign="right" /><TextInput value={connectionUsername} onChangeText={setConnectionUsername} placeholder="اسم المستخدم" placeholderTextColor="#64748B" style={[styles.input, styles.deviceSmallInput]} textAlign="right" /></View>
                  <TextInput value={connectionSecretRef} onChangeText={setConnectionSecretRef} placeholder="مرجع السر مثل EXTERNAL_DB_SECRET" placeholderTextColor="#64748B" style={styles.input} autoCapitalize="characters" textAlign="right" />
                  <Pressable disabled={saveConnectionMutation.isPending} onPress={() => void saveConnection()} style={[styles.primaryButton, saveConnectionMutation.isPending && styles.disabled]}><Text style={styles.primaryText}>{saveConnectionMutation.isPending ? "جارٍ الحفظ…" : "حفظ تعريف الاتصال"}</Text><Ionicons name="server-outline" size={17} color="#0A0D1F" /></Pressable>
                  <Text style={styles.integrationHeading}>تسجيل API Key كمرجع آمن</Text>
                  <TextInput value={keyProvider} onChangeText={setKeyProvider} placeholder="اسم المزود" placeholderTextColor="#64748B" style={styles.input} textAlign="right" />
                  <TextInput value={keyLabel} onChangeText={setKeyLabel} placeholder="اسم المفتاح داخل ZANOX" placeholderTextColor="#64748B" style={styles.input} textAlign="right" />
                  <TextInput value={keySecretRef} onChangeText={setKeySecretRef} placeholder="مرجع السر مثل PROVIDER_API_KEY" placeholderTextColor="#64748B" style={styles.input} autoCapitalize="characters" textAlign="right" />
                  <TextInput value={keyScopes} onChangeText={setKeyScopes} placeholder="الصلاحيات مفصولة بفواصل" placeholderTextColor="#64748B" style={styles.input} textAlign="right" />
                  <Pressable disabled={registerKeyMutation.isPending} onPress={() => void registerApiKey()} style={[styles.primaryButton, registerKeyMutation.isPending && styles.disabled]}><Text style={styles.primaryText}>{registerKeyMutation.isPending ? "جارٍ التسجيل…" : "تسجيل مرجع المفتاح"}</Text><Ionicons name="key-outline" size={17} color="#0A0D1F" /></Pressable>
                  <View style={styles.sessionListHeader}><Text style={styles.sessionListTitle}>الاتصالات المسجلة</Text><Pressable onPress={() => void connectionsQuery.refetch()}><Ionicons name="refresh-outline" size={17} color="#60A5FA" /></Pressable></View>
                  {connectionsQuery.data?.map((connection) => <View key={connection.id} style={styles.rootCard}><Text style={styles.rootCardSummary}>{connection.label} · {connection.kind}</Text><Text style={styles.rootCardMeta}>{connection.host} · مرجع السر: {connection.secretRef} · SSL مفعّل</Text><View style={styles.rootCardActions}><Pressable disabled={testConnectionMutation.isPending} onPress={() => void testConnection(connection.id)}><Text style={styles.policyEdit}>{testConnectionMutation.isPending ? "جارٍ الاختبار…" : "اختبار الاتصال"}</Text></Pressable><Pressable onPress={() => void removeConnectionMutation.mutateAsync({ id: connection.id }).then(() => connectionsQuery.refetch())}><Text style={styles.policyDelete}>حذف التعريف</Text></Pressable></View></View>)}
                  <Text style={styles.sessionListTitle}>مراجع API Keys</Text>
                  {apiKeysQuery.data?.map((key) => <View key={key.id} style={styles.rootCard}><Text style={styles.rootCardSummary}>{key.provider} · {key.label}</Text><Text style={styles.rootCardMeta}>مرجع السر: {key.secretRef} · الحالة: {key.status}</Text><Pressable onPress={() => void revokeKeyMutation.mutateAsync({ id: key.id }).then(() => apiKeysQuery.refetch())}><Text style={styles.policyDelete}>إلغاء المرجع</Text></Pressable></View>)}
                </>}
              </View>}

              {selectedArea === "files" && <View style={styles.rootPanel}>
                <View style={styles.rootHeader}><View><Text style={styles.rootTitle}>تعديل الملفات</Text><Text style={styles.rootHint}>اكتب Patch بمسار محدد للمراجعة. التطبيق المباشر مقفول حتى يتصل منفذ Git خارجي موثوق.</Text></View><Ionicons name="document-attach-outline" size={23} color="#C084FC" /></View>
                {!deviceControlAvailable ? <View style={styles.deviceGate}><Ionicons name="lock-closed-outline" size={17} color="#FDA4AF" /><View style={styles.deviceGateCopy}><Text style={styles.deviceGateText}>تعديل الملفات معطل حتى تتم مصادقة المالك على الخادم.</Text><Pressable style={styles.deviceAuthButton} onPress={() => void signInOwner()}><Text style={styles.deviceAuthText}>مصادقة المالك الآن</Text><Ionicons name="arrow-back" size={14} color="#FDA4AF" /></Pressable></View></View> : <>
                  <TextInput value={filePath} onChangeText={setFilePath} placeholder="مسار داخل المشروع مثل app/owner.tsx" placeholderTextColor="#64748B" style={styles.input} autoCapitalize="none" textAlign="right" />
                  <TextInput value={fileSummary} onChangeText={setFileSummary} placeholder="وصف التعديل" placeholderTextColor="#64748B" style={styles.input} textAlign="right" />
                  <TextInput value={filePatch} onChangeText={setFilePatch} placeholder="الصق Patch هنا — لا تضع مفاتيح أو كلمات مرور" placeholderTextColor="#64748B" style={styles.rootInput} multiline autoCapitalize="none" textAlign="left" />
                  <Pressable disabled={proposeFileMutation.isPending} onPress={() => void proposeFileChange()} style={[styles.primaryButton, proposeFileMutation.isPending && styles.disabled]}><Text style={styles.primaryText}>{proposeFileMutation.isPending ? "جارٍ الحفظ…" : "حفظ Patch للمراجعة"}</Text><Ionicons name="git-branch-outline" size={17} color="#0A0D1F" /></Pressable>
                  <View style={styles.sessionListHeader}><Text style={styles.sessionListTitle}>طلبات تعديل الملفات</Text><Pressable onPress={() => void fileChangesQuery.refetch()}><Ionicons name="refresh-outline" size={17} color="#C084FC" /></Pressable></View>
                  {fileChangesQuery.data?.map((change) => <View key={change.id} style={styles.rootCard}><Text style={styles.rootCardSummary}>{change.filePath} · {change.status}</Text><Text style={styles.rootCardMeta}>{change.summary} · خطورة {change.risk}</Text><Text style={styles.patchPreview}>{change.patch}</Text><View style={styles.rootCardActions}>{change.status === "awaiting_approval" && <Pressable onPress={() => void approveFileChange(change.id)}><Text style={styles.rootApprove}>اعتماد</Text></Pressable>}{(change.status === "awaiting_approval" || change.status === "approved") && <Pressable onPress={() => void applyFileChange(change.id)}><Text style={styles.policyEdit}>تطبيق مباشر</Text></Pressable>}<Pressable onPress={() => void cancelFileChange(change.id)}><Text style={styles.policyDelete}>إلغاء</Text></Pressable></View></View>)}
                </>}
              </View>}

              {selectedArea === "devices" && <View style={styles.devicePanel}>
                <Text style={styles.deviceTitle}>طلب جلسة تحكم بموافقة الجهاز</Text>
                <Text style={styles.deviceHint}>لن تبدأ أي جلسة قبل قبولها من الجهاز نفسه. وضع الدخول المفتوح يسمح بالمحادثة ولوحة المالك، لكنه لا يمنح جلسة خادم للتحكم بالأجهزة.</Text>
                {!deviceControlAvailable && <View style={styles.deviceGate}><Ionicons name="lock-closed-outline" size={17} color="#FDA4AF" /><View style={styles.deviceGateCopy}><Text style={styles.deviceGateText}>التحكم بالأجهزة معطل حتى تتم مصادقة المالك على الخادم.</Text><Pressable style={styles.deviceAuthButton} onPress={() => void signInOwner()}><Text style={styles.deviceAuthText}>مصادقة المالك الآن</Text><Ionicons name="arrow-back" size={14} color="#FDA4AF" /></Pressable></View></View>}
                <TextInput editable={deviceControlAvailable} value={deviceId} onChangeText={setDeviceId} placeholder="معرّف الجهاز" placeholderTextColor="#64748B" style={[styles.input, !deviceControlAvailable && styles.disabled]} textAlign="right" />
                <TextInput editable={deviceControlAvailable} value={deviceName} onChangeText={setDeviceName} placeholder="اسم الجهاز" placeholderTextColor="#64748B" style={[styles.input, !deviceControlAvailable && styles.disabled]} textAlign="right" />
                <View style={styles.deviceRow}><TextInput editable={deviceControlAvailable} value={devicePlatform} onChangeText={setDevicePlatform} placeholder="android أو ios" placeholderTextColor="#64748B" style={[styles.input, styles.deviceSmallInput, !deviceControlAvailable && styles.disabled]} autoCapitalize="none" textAlign="right" /><TextInput editable={deviceControlAvailable} value={deviceMinutes} onChangeText={setDeviceMinutes} placeholder="المدة بالدقائق" placeholderTextColor="#64748B" style={[styles.input, styles.deviceSmallInput, !deviceControlAvailable && styles.disabled]} keyboardType="number-pad" textAlign="right" /></View>
                <View style={styles.capabilityWrap}>{DEVICE_CAPABILITIES.map((capability) => <Pressable disabled={!deviceControlAvailable} key={capability.id} onPress={() => toggleDeviceCapability(capability.id)} style={[styles.capabilityChip, deviceCapabilities.includes(capability.id) && styles.capabilityChipActive, !deviceControlAvailable && styles.disabled]}><Text style={styles.capabilityText}>{capability.label}</Text></Pressable>)}</View>
                <Pressable disabled={!deviceControlAvailable || requestDeviceSessionMutation.isPending} style={[styles.primaryButton, (!deviceControlAvailable || requestDeviceSessionMutation.isPending) && styles.disabled]} onPress={() => void requestDeviceSession()}><Text style={styles.primaryText}>{requestDeviceSessionMutation.isPending ? "جارٍ إنشاء الطلب…" : "إنشاء طلب موافقة"}</Text><Ionicons name="phone-portrait-outline" size={17} color="#0A0D1F" /></Pressable>
                <View style={styles.sessionListHeader}><Text style={styles.sessionListTitle}>الجلسات الأخيرة</Text><Pressable disabled={!deviceControlAvailable} onPress={() => void deviceSessionsQuery.refetch()}><Ionicons name="refresh-outline" size={17} color={deviceControlAvailable ? "#67E8F9" : "#64748B"} /></Pressable></View>
                {deviceSessionsQuery.isLoading ? <Text style={styles.deviceHint}>جارٍ تحميل الجلسات…</Text> : deviceSessionsQuery.data?.length ? deviceSessionsQuery.data.map((session) => <View key={session.sessionId} style={styles.sessionCard}><View style={styles.sessionTop}><Text style={styles.sessionName}>{session.deviceName}</Text><Text style={styles.sessionStatus}>{SESSION_STATUS_LABELS[session.status] ?? session.status}</Text></View><Text style={styles.sessionMeta}>{session.platform} · {sessionCapabilityCount(session.capabilities)} صلاحيات · تنتهي {new Date(session.expiresAt).toLocaleString("ar-EG")}</Text>{(session.status === "pending" || session.status === "active") && <Pressable onPress={() => void revokeDeviceSession(session.sessionId)} style={styles.revokeButton}><Text style={styles.revokeText}>{revokeDeviceSessionMutation.isPending ? "جارٍ السحب…" : "سحب الجلسة"}</Text></Pressable>}</View>) : <Text style={styles.deviceHint}>لا توجد جلسات مسجلة لهذا المالك.</Text>}
              </View>}

              {selectedArea === "policy" && <View style={styles.policyPanel}>
                <View style={styles.policyHeader}><View><Text style={styles.policyTitle}>إدارة صلاحيات ZANOX</Text><Text style={styles.policyHint}>أضف صلاحية أو عدّلها، وستُحفظ مرتبطة بمالك المنصة في قاعدة البيانات.</Text></View><Ionicons name="shield-checkmark-outline" size={22} color="#2DD4BF" /></View>
                {!deviceControlAvailable ? <View style={styles.deviceGate}><Ionicons name="lock-closed-outline" size={17} color="#FDA4AF" /><View style={styles.deviceGateCopy}><Text style={styles.deviceGateText}>إدارة الصلاحيات معطلة حتى تتم مصادقة المالك على الخادم.</Text><Pressable style={styles.deviceAuthButton} onPress={() => void signInOwner()}><Text style={styles.deviceAuthText}>مصادقة المالك الآن</Text><Ionicons name="arrow-back" size={14} color="#FDA4AF" /></Pressable></View></View> : <>
                  <TextInput value={policyKey} onChangeText={setPolicyKey} placeholder="مفتاح الصلاحية مثل: web.search" placeholderTextColor="#64748B" style={styles.input} autoCapitalize="none" textAlign="right" />
                  <TextInput value={policyLabel} onChangeText={setPolicyLabel} placeholder="اسم الصلاحية" placeholderTextColor="#64748B" style={styles.input} textAlign="right" />
                  <TextInput value={policyDescription} onChangeText={setPolicyDescription} placeholder="وصف ما تسمح به الصلاحية أو تمنعه" placeholderTextColor="#64748B" style={styles.policyDescriptionInput} multiline textAlign="right" />
                  <Pressable onPress={() => setPolicyEnabled((current) => !current)} style={styles.policyToggle}><Ionicons name={policyEnabled ? "checkmark-circle" : "close-circle"} size={19} color={policyEnabled ? "#2DD4BF" : "#FDA4AF"} /><Text style={styles.policyToggleText}>{policyEnabled ? "الصلاحية مفعّلة" : "الصلاحية معطّلة"}</Text></Pressable>
                  <View style={styles.policyActions}><Pressable disabled={savePolicyMutation.isPending} onPress={() => void savePolicy()} style={[styles.primaryButton, styles.policySaveButton, savePolicyMutation.isPending && styles.disabled]}><Text style={styles.primaryText}>{savePolicyMutation.isPending ? "جارٍ الحفظ…" : policyId ? "حفظ التعديل" : "إضافة الصلاحية"}</Text><Ionicons name="save-outline" size={17} color="#0A0D1F" /></Pressable>{policyId && <Pressable onPress={clearPolicyEditor} style={styles.policyCancel}><Text style={styles.policyCancelText}>إلغاء التعديل</Text></Pressable>}</View>
                  <Text style={styles.sessionListTitle}>الصلاحيات المحفوظة</Text>
                  {policiesQuery.isLoading ? <Text style={styles.deviceHint}>جارٍ تحميل الصلاحيات…</Text> : policiesQuery.data?.length ? policiesQuery.data.map((policy) => <View key={policy.id} style={styles.policyCard}><View style={styles.policyCardTop}><Text style={styles.policyCardLabel}>{policy.label}</Text><Text style={styles.policyKey}>{policy.policyKey}</Text></View><Text style={styles.policyCardDescription}>{policy.description}</Text><View style={styles.policyCardActions}><Text style={[styles.policyState, { color: policy.enabled ? "#99F6E4" : "#FDA4AF" }]}>{policy.enabled ? "مفعّلة" : "معطّلة"}</Text><Pressable onPress={() => editPolicy(policy)}><Text style={styles.policyEdit}>تعديل</Text></Pressable><Pressable onPress={() => void removePolicy(policy.id)}><Text style={styles.policyDelete}>حذف</Text></Pressable></View></View>) : <Text style={styles.deviceHint}>لا توجد صلاحيات مخصصة بعد. أضف أول صلاحية من الحقول أعلاه.</Text>}
                </>}
              </View>}

              <ScrollView ref={messagesScrollRef} style={styles.messages} contentContainerStyle={styles.messagesContent} showsVerticalScrollIndicator={true} onContentSizeChange={() => messagesScrollRef.current?.scrollToEnd({ animated: true })}>
                {messages.map((message) => <View key={message.id} style={[styles.messageRow, message.role === "user" && styles.userRow]}>{message.role === "assistant" && <View style={styles.miniAvatar}><Text style={styles.miniAvatarText}>Z</Text></View>}<View style={[styles.bubble, message.role === "user" ? styles.userBubble : styles.assistantBubble]}><Text style={[styles.messageText, message.role === "user" && styles.userMessageText]}>{message.text}</Text></View></View>)}
              </ScrollView>

              <View style={styles.composer}><TextInput value={draft} onChangeText={setDraft} onSubmitEditing={() => void sendMessage()} placeholder="اكتب أمرًا للموقع أو المنصة…" placeholderTextColor="#64748B" style={styles.commandInput} multiline textAlign="right" /><Pressable style={[styles.micButton, recorderState.isRecording && styles.micButtonActive]} onPress={() => void toggleVoice()}><Ionicons name={recorderState.isRecording ? "stop" : "mic-outline"} size={20} color={recorderState.isRecording ? "#0A0D1F" : "#CBD5E1"} /></Pressable><Pressable style={[styles.sendButton, (!draft.trim() || chatMutation.isPending) && styles.disabled]} onPress={() => void sendMessage()}><Ionicons name={chatMutation.isPending ? "ellipsis-horizontal" : "arrow-up"} size={20} color="#0A0D1F" /></Pressable></View>
              <Text style={styles.voiceNote}>{recorderState.isRecording ? "التسجيل نشط… اضغط الميكروفون للإيقاف والتنفيذ." : "يمكنك استخدام الصوت أو النص. سيقرأ ZANOX الرد في الجلسة الصوتية."}</Text>

              <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.suggestionRow}>{suggestions.map((item) => <Pressable key={item} onPress={() => void sendMessage(item)} style={styles.suggestion}><Text style={styles.suggestionText}>{item}</Text></Pressable>)}</ScrollView>
              <View style={styles.report}><View style={styles.reportHeader}><Text style={styles.reportStatus}>تقرير التنفيذ</Text><Ionicons name="shield-checkmark-outline" size={18} color="#67E8F9" /></View><Text style={styles.reportText}>{report}</Text></View>
              <View style={styles.notice}><Ionicons name="flash-outline" size={17} color="#2DD4BF" /><Text style={styles.noticeText}>سياسة ZANOX التشغيلية يحددها المالك. وضع التنفيذ لا يضيف رأيًا أو جدالًا؛ وتبقى الإجراءات غير القابلة للعكس خلف تأكيد صريح وحدود الصلاحيات الأساسية.</Text></View>
            </View>
          )}
        </View>
      </KeyboardAvoidingView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  screen: { flex: 1, backgroundColor: "#0A0D1F" },
  container: { flex: 1, paddingHorizontal: 18, width: "100%", maxWidth: 900, alignSelf: "center" },
  topbar: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  back: { width: 40, height: 40, borderWidth: 1, borderColor: "#27304D", borderRadius: 13, alignItems: "center", justifyContent: "center" },
  brandMark: { width: 40, height: 40, borderRadius: 13, backgroundColor: "#8B5CF6", alignItems: "center", justifyContent: "center" },
  brandMarkText: { color: "#FFFFFF", fontSize: 22, fontWeight: "900" },
  ownerTag: { flexDirection: "row", alignItems: "center", gap: 6, backgroundColor: "#17113A", borderWidth: 1, borderColor: "#47327D", borderRadius: 99, paddingHorizontal: 10, paddingVertical: 7 },
  ownerDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: "#A78BFA" },
  ownerTagText: { color: "#C4B5FD", fontSize: 9, fontWeight: "900", letterSpacing: 1 },
  loginContent: { paddingBottom: 42 },
  hero: { alignItems: "center", paddingVertical: 30 },
  ownerAvatar: { width: 72, height: 72, borderRadius: 25, backgroundColor: "#8B5CF6", alignItems: "center", justifyContent: "center", marginBottom: 15 },
  ownerAvatarText: { color: "#FFFFFF", fontSize: 33, fontWeight: "900" },
  kicker: { color: "#67E8F9", fontSize: 10, fontWeight: "900", letterSpacing: 1.4 },
  title: { color: "#F8FAFC", fontSize: 25, fontWeight: "900", textAlign: "center", marginTop: 10 },
  subtitle: { color: "#94A3B8", fontSize: 12, marginTop: 7, textAlign: "center" },
  loginCard: { backgroundColor: "#11162B", borderWidth: 1, borderColor: "#303B61", borderRadius: 20, padding: 17 },
  cardHeader: { flexDirection: "row-reverse", alignItems: "center", gap: 8, marginBottom: 15 },
  cardTitle: { color: "#F8FAFC", fontSize: 15, fontWeight: "800" },
  input: { height: 50, backgroundColor: "#0A0D1F", borderWidth: 1, borderColor: "#27304D", borderRadius: 12, color: "#F8FAFC", paddingHorizontal: 13, marginBottom: 10, fontSize: 13 },
  primaryButton: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "center", gap: 8, backgroundColor: "#A78BFA", borderRadius: 12, height: 49, marginTop: 3 },
  primaryText: { color: "#0A0D1F", fontSize: 13, fontWeight: "900" },
  oauthButton: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "center", gap: 7, borderWidth: 1, borderColor: "#47327D", backgroundColor: "#151033", borderRadius: 12, height: 45, marginTop: 9 },
  oauthText: { color: "#C4B5FD", fontSize: 12, fontWeight: "800" },
  helper: { color: "#64748B", fontSize: 10, lineHeight: 16, textAlign: "right", marginTop: 11 },
  dashboard: { flex: 1, paddingTop: 22, paddingBottom: 12 },
  header: { flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "flex-start" },
  eyebrow: { color: "#67E8F9", fontSize: 10, fontWeight: "900", letterSpacing: 1.3, textAlign: "right", marginBottom: 7 },
  dashboardTitle: { color: "#F8FAFC", fontSize: 24, fontWeight: "900", textAlign: "right" },
  dashboardSub: { color: "#94A3B8", fontSize: 11, lineHeight: 18, textAlign: "right", marginTop: 8, marginBottom: 13 },
  onlinePill: { flexDirection: "row", alignItems: "center", gap: 6, borderWidth: 1, borderColor: "#225E5B", backgroundColor: "#0D2528", paddingHorizontal: 10, paddingVertical: 6, borderRadius: 99 },
  onlineDot: { width: 7, height: 7, borderRadius: 4, backgroundColor: "#2DD4BF" },
  onlineText: { color: "#99F6E4", fontSize: 10, fontWeight: "700" },
  areaStrip: { flexDirection: "row-reverse", gap: 8, paddingBottom: 10 },
  areaChip: { flexDirection: "row-reverse", alignItems: "center", gap: 6, borderWidth: 1, borderColor: "#27304D", backgroundColor: "#10162B", borderRadius: 11, paddingHorizontal: 11, paddingVertical: 8 },
  areaText: { color: "#94A3B8", fontSize: 11, fontWeight: "700" },
  areaTextActive: { color: "#F8FAFC" },
  devicePanel: { backgroundColor: "#11162B", borderWidth: 1, borderColor: "#4C1D3D", borderRadius: 17, padding: 13, marginBottom: 10 },
  deviceTitle: { color: "#FDA4AF", fontSize: 14, fontWeight: "900", textAlign: "right" },
  deviceHint: { color: "#CBD5E1", fontSize: 10, lineHeight: 17, textAlign: "right", marginTop: 5, marginBottom: 10 },
  deviceGate: { flexDirection: "row-reverse", alignItems: "center", gap: 7, backgroundColor: "#3A172A", borderWidth: 1, borderColor: "#7F1D1D", borderRadius: 10, padding: 9, marginBottom: 10 },
  deviceGateCopy: { flex: 1, alignItems: "flex-end", gap: 7 },
  deviceGateText: { color: "#FDA4AF", fontSize: 10, lineHeight: 16, textAlign: "right" },
  deviceAuthButton: { flexDirection: "row-reverse", alignItems: "center", gap: 5, borderWidth: 1, borderColor: "#9F4255", borderRadius: 8, paddingHorizontal: 9, paddingVertical: 6 },
  deviceAuthText: { color: "#FDA4AF", fontSize: 10, fontWeight: "800" },
  deviceRow: { flexDirection: "row", gap: 8 },
  deviceSmallInput: { flex: 1 },
  capabilityWrap: { flexDirection: "row-reverse", flexWrap: "wrap", gap: 7, marginBottom: 12 },
  capabilityChip: { borderWidth: 1, borderColor: "#334155", backgroundColor: "#0D1328", borderRadius: 10, paddingHorizontal: 9, paddingVertical: 7 },
  capabilityChipActive: { borderColor: "#FB7185", backgroundColor: "#3A172A" },
  capabilityText: { color: "#E2E8F0", fontSize: 10 },
  sessionListHeader: { flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center", marginTop: 16, marginBottom: 8 },
  sessionListTitle: { color: "#FDA4AF", fontSize: 12, fontWeight: "900", textAlign: "right" },
  sessionCard: { backgroundColor: "#0D1328", borderWidth: 1, borderColor: "#3F2947", borderRadius: 12, padding: 10, marginTop: 7 },
  sessionTop: { flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center" },
  sessionName: { color: "#F8FAFC", fontSize: 12, fontWeight: "800" },
  sessionStatus: { color: "#99F6E4", fontSize: 10, fontWeight: "800" },
  sessionMeta: { color: "#94A3B8", fontSize: 10, lineHeight: 17, textAlign: "right", marginTop: 5 },
  revokeButton: { alignSelf: "flex-end", borderWidth: 1, borderColor: "#7F1D1D", backgroundColor: "#3A172A", borderRadius: 8, paddingHorizontal: 9, paddingVertical: 6, marginTop: 8 },
  revokeText: { color: "#FDA4AF", fontSize: 10, fontWeight: "800" },
  messages: { flex: 1, backgroundColor: "#0D1328", borderWidth: 1, borderColor: "#202A4A", borderRadius: 18 },
  messagesContent: { padding: 16, gap: 15, paddingBottom: 28 },
  messageRow: { width: "100%", maxWidth: 760, alignSelf: "center", flexDirection: "row-reverse", alignItems: "flex-start", gap: 8 },
  userRow: { flexDirection: "row", justifyContent: "flex-start" },
  miniAvatar: { width: 27, height: 27, borderRadius: 13, backgroundColor: "#8B5CF6", alignItems: "center", justifyContent: "center" },
  miniAvatarText: { color: "#FFFFFF", fontSize: 13, fontWeight: "900" },
  bubble: { paddingHorizontal: 14, paddingVertical: 11, borderRadius: 16 },
  assistantBubble: { flex: 1, backgroundColor: "#151B34", borderTopRightRadius: 5, borderWidth: 1, borderColor: "#202A4A" },
  userBubble: { maxWidth: "82%", backgroundColor: "#5B35B6", borderTopLeftRadius: 5 },
  messageText: { color: "#E2E8F0", fontSize: 13, lineHeight: 22, textAlign: "right" },
  userMessageText: { color: "#FFFFFF" },
  composer: { minHeight: 57, flexDirection: "row-reverse", alignItems: "flex-end", gap: 7, backgroundColor: "#11162B", borderWidth: 1, borderColor: "#303B61", borderRadius: 18, padding: 8, marginTop: 10 },
  commandInput: { flex: 1, maxHeight: 92, color: "#F8FAFC", fontSize: 13, paddingHorizontal: 8, paddingVertical: 8, textAlignVertical: "top" },
  micButton: { width: 37, height: 37, alignItems: "center", justifyContent: "center" },
  micButtonActive: { backgroundColor: "#2DD4BF", borderRadius: 12 },
  sendButton: { width: 38, height: 38, borderRadius: 13, backgroundColor: "#A78BFA", alignItems: "center", justifyContent: "center" },
  disabled: { opacity: 0.4 },
  voiceNote: { color: "#64748B", fontSize: 10, textAlign: "right", marginTop: 7 },
  suggestionRow: { flexDirection: "row-reverse", gap: 7, paddingVertical: 10 },
  suggestion: { borderWidth: 1, borderColor: "#27304D", backgroundColor: "#10162B", borderRadius: 10, paddingHorizontal: 10, paddingVertical: 8 },
  suggestionText: { color: "#A5B4FC", fontSize: 10 },
  report: { backgroundColor: "#101C30", borderWidth: 1, borderColor: "#164E63", borderRadius: 15, padding: 12 },
  reportHeader: { flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center" },
  reportStatus: { color: "#67E8F9", fontSize: 10, fontWeight: "900", letterSpacing: 1 },
  reportText: { color: "#CFFAFE", fontSize: 11, lineHeight: 19, textAlign: "right", marginTop: 8 },
  notice: { flexDirection: "row-reverse", alignItems: "center", gap: 7, backgroundColor: "#0E2524", borderWidth: 1, borderColor: "#145A53", borderRadius: 12, padding: 10, marginTop: 9 },
  noticeText: { flex: 1, color: "#99F6E4", fontSize: 10, textAlign: "right", lineHeight: 17 },
  policyPanel: { backgroundColor: "#101C30", borderWidth: 1, borderColor: "#145A53", borderRadius: 17, padding: 13, marginBottom: 10 },
  policyHeader: { flexDirection: "row-reverse", alignItems: "flex-start", justifyContent: "space-between", gap: 10, marginBottom: 12 },
  policyTitle: { color: "#99F6E4", fontSize: 14, fontWeight: "900", textAlign: "right" },
  policyHint: { color: "#CBD5E1", fontSize: 10, lineHeight: 17, textAlign: "right", marginTop: 5 },
  policyDescriptionInput: { minHeight: 86, backgroundColor: "#0A0D1F", borderWidth: 1, borderColor: "#27304D", borderRadius: 12, color: "#F8FAFC", padding: 13, marginBottom: 10, fontSize: 12, lineHeight: 18, textAlignVertical: "top" },
  policyToggle: { flexDirection: "row-reverse", alignItems: "center", alignSelf: "flex-end", gap: 7, marginBottom: 10 },
  policyToggleText: { color: "#CBD5E1", fontSize: 11, fontWeight: "800" },
  policyActions: { flexDirection: "row-reverse", alignItems: "center", gap: 9, marginBottom: 16 },
  policySaveButton: { flex: 1 },
  policyCancel: { borderWidth: 1, borderColor: "#475569", borderRadius: 10, paddingHorizontal: 12, paddingVertical: 12 },
  policyCancelText: { color: "#CBD5E1", fontSize: 11, fontWeight: "800" },
  policyCard: { backgroundColor: "#0D1328", borderWidth: 1, borderColor: "#24505A", borderRadius: 12, padding: 10, marginTop: 8 },
  policyCardTop: { flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center", gap: 8 },
  policyCardLabel: { color: "#F8FAFC", fontSize: 12, fontWeight: "900" },
  policyKey: { color: "#67E8F9", fontSize: 10, fontFamily: Platform.OS === "ios" ? "Menlo" : "monospace" },
  policyCardDescription: { color: "#CBD5E1", fontSize: 10, lineHeight: 17, textAlign: "right", marginTop: 7 },
  policyCardActions: { flexDirection: "row-reverse", alignItems: "center", gap: 14, marginTop: 9 },
  policyState: { flex: 1, fontSize: 10, fontWeight: "800", textAlign: "right" },
  policyEdit: { color: "#A78BFA", fontSize: 10, fontWeight: "900" },
  policyDelete: { color: "#FDA4AF", fontSize: 10, fontWeight: "900" },
  rootPanel: { backgroundColor: "#171A2B", borderWidth: 1, borderColor: "#73511A", borderRadius: 17, padding: 13, marginBottom: 10 },
  rootHeader: { flexDirection: "row-reverse", alignItems: "flex-start", justifyContent: "space-between", gap: 10, marginBottom: 12 },
  rootTitle: { color: "#FDE68A", fontSize: 14, fontWeight: "900", textAlign: "right" },
  rootHint: { color: "#CBD5E1", fontSize: 10, lineHeight: 17, textAlign: "right", marginTop: 5 },
  rootInput: { minHeight: 94, backgroundColor: "#0A0D1F", borderWidth: 1, borderColor: "#73511A", borderRadius: 12, color: "#F8FAFC", padding: 13, marginBottom: 10, fontSize: 12, lineHeight: 18, textAlignVertical: "top" },
  rootCard: { backgroundColor: "#0D1328", borderWidth: 1, borderColor: "#73511A", borderRadius: 12, padding: 10, marginTop: 8 },
  rootCardTop: { flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center" },
  rootCardStatus: { color: "#FDE68A", fontSize: 10, fontWeight: "900" },
  rootCardRisk: { color: "#FBBF24", fontSize: 10, fontWeight: "800" },
  rootCardSummary: { color: "#F8FAFC", fontSize: 12, fontWeight: "800", textAlign: "right", marginTop: 7 },
  rootCardMeta: { color: "#CBD5E1", fontSize: 10, lineHeight: 17, textAlign: "right", marginTop: 5 },
  rootCardActions: { flexDirection: "row-reverse", alignItems: "center", gap: 15, marginTop: 10 },
  rootApprove: { color: "#99F6E4", fontSize: 10, fontWeight: "900" },
  integrationHeading: { color: "#93C5FD", fontSize: 12, fontWeight: "900", textAlign: "right", marginTop: 14, marginBottom: 8 },
  patchPreview: { color: "#D8B4FE", backgroundColor: "#090D1D", borderWidth: 1, borderColor: "#4C1D95", borderRadius: 9, padding: 9, marginTop: 8, fontSize: 10, lineHeight: 16, fontFamily: Platform.OS === "ios" ? "Menlo" : "monospace", textAlign: "left" },
});
